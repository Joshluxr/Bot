# Testing notes

The maintained validation path for this repository is the `searchk4_fast` binary.

## Quick smoke test

```bash
make test
```

This does the following:

1. builds `searchk4_fast`
2. creates a small temporary `test_patterns.txt`
3. runs a short sequential search from `0x1` with `-threads 1024`
4. removes temporary outputs and state files

## Resume test recommended on a CUDA host

Run a fresh search, stop it after several iterations, then resume it from the saved state file and confirm that:

- the reported iteration count continues instead of restarting from zero
- total covered keys continue monotonically
- any match that is written passes host-side verification

## Edge-case starts recommended on a CUDA host

Test at least the following starts:

- `0x1`
- `0x400`
- a start aligned to a multiple of `1024`

Those cases exercise the denominator-handling and thread-initialization edge paths that were fixed in this patch set.

## Historical test files

The top-level `test_*.cu` files are retained from earlier debugging work. They are useful for experimentation, but they are not the primary compatibility contract for the maintained code path.
