# SearchK4

CUDA-based Bitcoin P2PKH vanity-prefix searcher built around VanitySearch GPU primitives and a fast sequential thread initializer.

The maintained implementation is **`SearchK4_fast.cu`**. The older `SearchK4.cu` file is kept as a historical reference, not the primary supported path.

## What it does

- Searches **mainnet P2PKH** addresses only (`1...` Base58Check prefixes)
- Loads vanity prefixes from `patterns.txt`
- Starts from an explicit decimal or hexadecimal private key
- Assigns each GPU thread a **non-overlapping 1024-key window**
- Saves and resumes progress from a state file
- Reconstructs private keys for matches and verifies them host-side before writing output

It does **not** search P2SH, bech32, or arbitrary script types.

## Supported build

`make searchk4_fast`

That target builds the maintained binary `searchk4_fast`.

`make searchk4` still exists, but it builds the legacy/reference file.

## Build

```bash
make searchk4_fast
```

Optional environment overrides:

```bash
make searchk4_fast CUDA_PATH=/usr/local/cuda CCAP=89
```

`CCAP` is the CUDA compute capability without a dot, for example:

- `89` for Ada cards such as RTX 4090
- `86` for Ampere cards such as RTX 3090
- `75` for Turing cards such as RTX 2080

If `nvidia-smi` is available, the Makefile attempts to detect `CCAP` automatically.

## Quick smoke test

The maintained smoke-test path is:

```bash
make test
```

That target builds `searchk4_fast` and runs a short test search against a tiny temporary prefix set.
The older standalone `test_*.cu` files are kept as historical probes and debugging aids, not as the primary supported validation path.

## Usage

```bash
# Decimal start
./searchk4_fast -patterns patterns.txt -start 12345678901234567890 -gpu 0

# Hex start
./searchk4_fast -patterns patterns.txt -startx 0xAB54A98CEB1F0AD2 -gpu 0

# Resume from state file
./searchk4_fast -patterns patterns.txt -state gpu0.state -gpu 0

# Explicit thread count
./searchk4_fast -patterns patterns.txt -startx 0x1 -threads 1024 -gpu 0
```

## Command-line options

- `-patterns <file>`: required pattern file
- `-start <decimal>`: starting private key in decimal
- `-startx <hex>`: starting private key in hex, with or without `0x`
- `-state <file>`: resume/save state file
- `-threads <count>`: thread count, must be at least 64 and a multiple of 64
- `-gpu <id>`: CUDA device index
- `-o <file>`: output file

Defaults:

- threads: `1024`
- output file: `found_k4_gpu<id>.txt`
- state file: `gpu<id>.state`

If a **v2 state file** is resumed and `-threads` is omitted, the thread count is restored from the state header automatically.

## Pattern file rules

- one pattern per line
- blank lines and `#` comments are ignored
- pattern must start with `1`
- only valid Base58 characters are accepted
- maximum supported prefix length is **35 characters**

Overlong or malformed patterns are rejected instead of truncated.

## Sequential coverage model

Each thread starts at:

```text
baseKey + tid * 1024
```

Each kernel iteration covers the thread’s local 1024-key window and then advances the whole grid by:

```text
nbThread * 1024
```

So the first iteration covers:

```text
[baseKey, baseKey + nbThread * 1024)
```

without thread-to-thread overlap.

## State format

Current state files use a **versioned v2 header** with:

- magic + version
- thread count
- step size
- total keys covered
- iteration count
- keys-per-iteration
- base key
- key-buffer size
- checksum

Legacy state files are still loadable when their size matches the requested thread count. When a legacy state is resumed, the next save upgrades it to the new format.

## Match verification

Before a match is written out, the host now:

1. reconstructs the candidate private key
2. derives the public key again with host-side secp256k1 math
3. derives the address again from the reconstructed key
4. compares the derived hash160 and address to the GPU-reported result

Only verified matches are written to disk.

## Important fixes in this revision

### Resume correctness

The maintained build now restores:

- the iteration counter
- total covered keys
- the base key
- the sequential delta metadata needed to keep non-overlapping coverage after resume

### Strict input validation

Starting keys are now rejected when they are:

- malformed
- outside the valid secp256k1 range
- too large for 256 bits

The parser no longer silently strips arbitrary characters or truncates oversized hex input.

### Zero-denominator handling

The code now masks zero denominators before grouped inversion and falls back to exact point-add/double handling for those edge cases.

This fixes aligned and low-range starts that could previously poison an entire inversion batch.

### Host-side verification

Matches are re-derived on the host before they are written, preventing bad reconstructions from being emitted as valid results.

### Safer thread selection

`-threads` is now validated and documented. Invalid values fail fast instead of silently truncating the launch grid.

### Quieter hot loop

Per-iteration debug spam was removed from the main search loop. Progress reporting is still kept, but the hot path no longer floods stdout.

## Files

- `SearchK4_fast.cu` — maintained implementation
- `SearchK4.cu` — legacy/reference implementation
- `CPUGroup.h` — CPU precomputed generator table
- `GPUGroup.h` — GPU precomputed group table from VanitySearch
- `GPUMath.h` — GPU field/group math from VanitySearch
- `GPUHash.h` — GPU hashing primitives from VanitySearch
- `PATCH_NOTES_2026-04-19.md` — detailed patch record for this revision

## Notes

- This repository is for **mainnet P2PKH vanity prefix search** only.
- The current codebase now validates and documents resume behavior much more strictly, but very long unattended GPU runs should still be tested on the target machine before production-scale use.
- This environment did not provide `nvcc` or a GPU, so the code in this revision was patched and checked statically rather than benchmarked live here.
