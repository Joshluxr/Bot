# SearchK4 — GPU Sequential Key Search

A GPU-accelerated secp256k1 key-range scanner with Jacobian coordinates, Montgomery batch inversion, and a precomputed generator table. Built around VanitySearch's GPU primitives with a custom sequential search driver.

Configured for Bitcoin Puzzle Transaction addresses #71–#74 (see `patterns.txt`).

## Quick start

```bash
make                                              # builds ./searchk4_fast
make smoke                                        # sanity test against Puzzle #1
./searchk4_fast -patterns patterns.txt \
    -direct -bits 71 -gpu 0                       # search Puzzle #71
```

## What it does

Given a starting private key `k_start`, an end key `k_end`, and a set of target addresses, the tool iterates over the key range, derives the Bitcoin address (P2PKH) for each candidate key, and reports matches. Keys are scanned in blocks of `nbThread × STEP_SIZE` per GPU iteration, using VanitySearch's group-symmetry trick to check 1024 keys per thread per inner loop with only one modular inversion per block.

## Modes

### `-direct` (recommended)

Hash160-direct mode. The tool Base58-decodes each address in `patterns.txt` on the host, uploads the 20-byte hash160s to GPU constant memory, and in the kernel compares the computed hash160 against the target list directly. No Base58 encoding runs in the hot path. Also skips the uncompressed-address check (puzzle addresses are all compressed).

Requires full 34-character addresses in `patterns.txt` — not prefixes. Any non-address line is rejected.

### Legacy prefix mode (default)

Generates a Base58 address string on the GPU for every candidate and does a character-by-character prefix match. Kept for backwards compatibility with vanity-address workflows; not recommended for puzzle work.

## Command-line options

| Flag | Description |
|---|---|
| `-patterns <file>` | Required. Address list (full addresses in direct mode, prefixes otherwise). |
| `-direct` | Enable hash160-direct mode. |
| `-start <dec>` | Starting private key, decimal. |
| `-startx <hex>` | Starting private key, hex (`0x` prefix optional). |
| `-endx <hex>` | End key (inclusive). Kernel terminates when range exhausted. |
| `-bits <N>` | Shortcut: set range to `[2^(N-1), 2^N - 1]`. Overridden by explicit `-startx`/`-endx`. |
| `-state <file>` | Resume from state file. See "Resume behaviour" below. |
| `-threads <N>` | CUDA thread count. Default: 1024 (prefix mode), 16384 (direct mode). |
| `-gpu <id>` | GPU device ID. |
| `-o <file>` | Output file for matches. Default: `found_k4.txt`. |
| `-verbose` | Print per-iteration progress (noisy). |

## Multi-GPU

Run one instance per GPU, dividing the range manually. For Puzzle #71 on 4 GPUs, split `[0x400…, 0x7ff…]` into quarters:

```bash
./searchk4_fast -patterns patterns.txt -direct -gpu 0 \
    -startx 0x400000000000000000 -endx 0x4FFFFFFFFFFFFFFFFF -state g0.state
./searchk4_fast -patterns patterns.txt -direct -gpu 1 \
    -startx 0x500000000000000000 -endx 0x5FFFFFFFFFFFFFFFFF -state g1.state
./searchk4_fast -patterns patterns.txt -direct -gpu 2 \
    -startx 0x600000000000000000 -endx 0x6FFFFFFFFFFFFFFFFF -state g2.state
./searchk4_fast -patterns patterns.txt -direct -gpu 3 \
    -startx 0x700000000000000000 -endx 0x7FFFFFFFFFFFFFFFFF -state g3.state
```

## Resume behaviour

State files are written every 500 iterations and on clean exit (SIGINT/SIGTERM). The v3 format stores:
- 8-byte magic `SK4STv03`
- keys-covered counter
- **iter counter** (new in v3 — without this, post-resume matches reconstruct with the wrong private key)
- 256-bit base key
- `nbThread` at save time
- per-thread keys

On resume with a different `-threads`, the program errors out with the required value. v2 and v1 state files are still readable — v2 loses `iter` and prints a warning (next save upgrades the file to v3); v1 loses `iter` and `nbThread`.

## Safety / correctness guarantees

Every reported match is re-verified on the host before being written to `found_k4.txt`:

1. Reconstruct the private key from `(tid, incr, iter, parity)`.
2. Re-derive `hash160 = RIPEMD160(SHA256(compressed_pubkey))` on the host from scratch.
3. Compare against the hash160 the GPU reported.

A verified match logs with `verified=yes`. A mismatch (which would indicate a reconstruction bug or GPU memory corruption) logs with `UNVERIFIED` and a loud warning in `found_k4.txt`. Never import a key from an `UNVERIFIED` line without investigation.

Input validation is strict: non-hex chars in `-startx`, non-digit chars in `-start`, values past `2^256`, `-threads` not a multiple of 64, negative `-gpu`, `-bits` out of `[0, 256]`, or a start key of 0 or `>= N` all error out before any search begins.

## Building

Auto-detects compute capability via `nvidia-smi`. Falls back to `sm_120` (Blackwell / RTX 5090). Override:

```bash
make CCAP=89     # Ada (RTX 4090)
make CCAP=86     # Ampere (RTX 3090)
make CCAP=75     # Turing (RTX 2080)
make CCAP=120    # Blackwell (RTX 5090)
```

Requires CUDA 12+ for Blackwell, CUDA 11.8+ for Ada/Ampere/Turing.

## Architecture

### Host-side key initialization

On start, the host:
1. Computes `P_0 = k_start × G` via Jacobian double-and-add (~256 doublings + ~128 mixed-adds, one final inversion).
2. Computes thread starting points `P_t = P_0 + (t × STEP_SIZE) × G` using Montgomery batch inversion: N sequential keys need 1 inversion + (3N − 3) multiplications instead of N inversions.
3. Computes the per-iteration advance delta `(nbThread × STEP_SIZE) × G` and uploads it to device constant memory. The kernel's inner loop covers STEP_SIZE keys per thread per iteration; the constant delta then slides every thread forward by the full `nbThread × STEP_SIZE` step so iterations don't overlap.
4. Uploads target hash160s (direct mode) or raw prefix strings (prefix mode) to constant memory.

### GPU inner loop

Each thread holds its current point `(px, py)` in affine coordinates. For each inner step, the kernel:
1. Computes `dx[i] = G[i].x − px` for 512 generator multiples.
2. Single grouped inversion `_ModInvGrouped` (VanitySearch's batched-inversion macro) gives all 512 `1/dx[i]` simultaneously.
3. For each `i`, computes `(px ± i×G).x` and `.y` by standard secp256k1 point addition using the precomputed inverse.
4. Hashes each resulting point's compressed pubkey with SHA256+RIPEMD160 (`_GetHash160CompSym` produces both Y-parity variants from one call).
5. Compares the hash160 against targets (direct mode) or generates Base58 and does prefix match (legacy mode).

### Memory layout

Keys are stored with VanitySearch's strided layout to get coalesced GPU reads. For `NB_THREAD_PER_GROUP = 64`:

```
Block b, Thread t:
  X[0..3] at indices  b*512 + t + 0*64, +1*64, +2*64, +3*64
  Y[0..3] at indices  b*512 + t + 4*64, +5*64, +6*64, +7*64
```

Adjacent threads read adjacent memory → one 128-byte cache line serves a warp.

## Safety / restraint

This build is restricted on purpose:

1. **Direct mode requires full P2PKH addresses.** Prefixes are rejected. The kernel only fires on an exact 20-byte hash160 match. No near-hits, no prefix collisions with unintended addresses.

2. **Range clamping is available and documented.** `-endx` and `-bits N` both constrain the scan to a specific range. Without one of these, the scan walks indefinitely; the README and `--help` both recommend using them.

3. **`patterns.txt` contains exactly four addresses**, all Bitcoin Puzzle Transaction targets with public ranges and designated solver rewards. No dormant third-party addresses. No short prefixes. If you need additional puzzle targets (e.g. #75 onward), add them explicitly — but see the time-to-solve math at the bottom of `patterns.txt` before doing so.

4. **Smoke test against Puzzle #1** (`make smoke`) proves end-to-end correctness — key derivation, hash160, direct-match, WIF reconstruction — in under a second. Run it before any real workload.

## Credits

- [VanitySearch](https://github.com/JeanLucPons/VanitySearch) by Jean Luc Pons — GPU primitives, memory layout, `_ModInvGrouped`, Base58 kernel, hash pipeline.
- [hyperelliptic.org](https://hyperelliptic.org/EFD/g1p/auto-shortw-jacobian-0.html) — Jacobian coordinate formulas.
- Montgomery batch inversion technique (standard cryptographic literature).

## License

GPL v3.0 (inherits from VanitySearch).
