/*
 * SearchK4.cu - Direct vanity address search with sequential keyspace support
 * Uses proper GPU Base58 encoding and string matching
 * Based on VanitySearch by Jean Luc PONS and BloomSearch32K3 sequential logic
 *
 * Features:
 * - Sequential keyspace search from specified start point
 * - Supports both decimal and hex start values
 * - Full private key reconstruction on match
 * - Resume from state files
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <cuda.h>
#include <cuda_runtime.h>
#include <time.h>
#include <signal.h>
#include <sys/stat.h>

#include "GPUGroup.h"
#include "GPUMath.h"
#include "GPUHash.h"
#include "CPUGroup.h"
#include "ripemd160.h"    // host-side post-match verification

#define NB_THREAD_PER_GROUP 64
#define MAX_FOUND 65536
#define STEP_SIZE 1024
#define K4_MAX_PATTERNS 256
#define P2PKH 0

// Base58 alphabet
__device__ __constant__ char pszBase58[] = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

// Pattern storage - each pattern is null-terminated, max 35 chars
// Used in prefix-match mode (legacy vanity behaviour).
__device__ __constant__ char d_patterns[K4_MAX_PATTERNS][36];
__device__ __constant__ int d_pattern_lens[K4_MAX_PATTERNS];
__device__ __constant__ int d_num_patterns;

// Hash160 target storage (20 bytes = 5 uint32_t per target).
// Used in hash160-direct mode for known-target puzzle search:
// skip Base58 entirely in the kernel, compare raw hash160 bytes.
__device__ __constant__ uint32_t d_target_h160[K4_MAX_PATTERNS][5];
__device__ __constant__ int d_num_targets;
// 0 = legacy prefix-match mode (checks compressed + uncompressed, runs Base58)
// 1 = hash160-direct mode (checks compressed only, no Base58 in hot path)
__device__ __constant__ int d_direct_mode;

// Range end (for -endx clamping). If d_have_endx != 0 the kernel writes a
// termination flag into the found-buffer when the last thread's key passes end.
// Stored as 256-bit little-endian, same layout as g_baseKey.
__device__ __constant__ uint64_t d_endKey[4];
__device__ __constant__ int d_have_endx;

// Sequential mode delta: (nbThread * STEP_SIZE) * G
// This is computed at runtime and copied to device memory
// Used to advance all threads by the correct amount for non-overlapping ranges
__device__ __constant__ uint64_t d_seqDeltaX[4];
__device__ __constant__ uint64_t d_seqDeltaY[4];
__device__ __constant__ int d_useSeqDelta;  // 0 = use _2Gn, 1 = use sequential delta

volatile bool running = true;
void sighandler(int s) { running = false; printf("\nStopping...\n"); }

// =====================================================================================
// SECP256K1 CPU-SIDE ELLIPTIC CURVE MATH (for key initialization)
// =====================================================================================

static const uint64_t SECP_P[4] = {
    0xFFFFFFFEFFFFFC2FULL, 0xFFFFFFFFFFFFFFFFULL,
    0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL
};

static const uint64_t SECP_N[4] = {  // Group order
    0xBFD25E8CD0364141ULL, 0xBAAEDCE6AF48A03BULL,
    0xFFFFFFFFFFFFFFFEULL, 0xFFFFFFFFFFFFFFFFULL
};

static const uint64_t SECP_GX[4] = {
    0x59F2815B16F81798ULL, 0x029BFCDB2DCE28D9ULL,
    0x55A06295CE870B07ULL, 0x79BE667EF9DCBBACULL
};

static const uint64_t SECP_GY[4] = {
    0x9C47D08FFB10D4B8ULL, 0xFD17B448A6855419ULL,
    0x5DA4FBFC0E1108A8ULL, 0x483ADA7726A3C465ULL
};

// Global base key for private key reconstruction
static uint64_t g_baseKey[4] = {0, 0, 0, 0};
static bool g_sequentialMode = false;
static int g_nbThread = 16384;
// Iter counter carried forward across resume. Zero on a fresh start or a
// v1/v2 resume (where iter was not stored).
static uint64_t g_resumedIter = 0;

// 256-bit comparison
static int cmp256(const uint64_t* a, const uint64_t* b) {
    for (int i = 3; i >= 0; i--) {
        if (a[i] > b[i]) return 1;
        if (a[i] < b[i]) return -1;
    }
    return 0;
}

// 256-bit addition: r = a + b, returns carry
static uint64_t add256(uint64_t* r, const uint64_t* a, const uint64_t* b) {
    __uint128_t c = 0;
    for (int i = 0; i < 4; i++) {
        c += (__uint128_t)a[i] + b[i];
        r[i] = (uint64_t)c;
        c >>= 64;
    }
    return (uint64_t)c;
}

// 256-bit subtraction: r = a - b, returns borrow
static uint64_t sub256(uint64_t* r, const uint64_t* a, const uint64_t* b) {
    __uint128_t c = 0;
    for (int i = 0; i < 4; i++) {
        __uint128_t diff = (__uint128_t)a[i] - b[i] - c;
        r[i] = (uint64_t)diff;
        c = (diff >> 64) ? 1 : 0;
    }
    return c;
}

// Add 64-bit value to 256-bit: r = a + b
static uint64_t add256_scalar(uint64_t* r, const uint64_t* a, uint64_t b) {
    __uint128_t c = b;
    for (int i = 0; i < 4; i++) {
        c += a[i];
        r[i] = (uint64_t)c;
        c >>= 64;
    }
    return (uint64_t)c;
}

// Modular addition: r = (a + b) mod p
static void mod_add(uint64_t* r, const uint64_t* a, const uint64_t* b) {
    uint64_t c = add256(r, a, b);
    if (c || cmp256(r, SECP_P) >= 0) {
        sub256(r, r, SECP_P);
    }
}

// Modular subtraction: r = (a - b) mod p
static void mod_sub(uint64_t* r, const uint64_t* a, const uint64_t* b) {
    uint64_t c = sub256(r, a, b);
    if (c) {
        add256(r, r, SECP_P);
    }
}

// Modular multiplication: r = (a * b) mod p
// Fixed modular multiplication for secp256k1
// p = 2^256 - 0x1000003D1
static void mod_mul(uint64_t* r, const uint64_t* a, const uint64_t* b) {
    __uint128_t t[8] = {0};
    for (int i = 0; i < 4; i++) {
        __uint128_t c = 0;
        for (int j = 0; j < 4; j++) {
            c += t[i + j] + (__uint128_t)a[i] * b[j];
            t[i + j] = (uint64_t)c;
            c >>= 64;
        }
        t[i + 4] = c;
    }

    uint64_t low[4] = {(uint64_t)t[0], (uint64_t)t[1], (uint64_t)t[2], (uint64_t)t[3]};
    uint64_t high[4] = {(uint64_t)t[4], (uint64_t)t[5], (uint64_t)t[6], (uint64_t)t[7]};

    uint64_t res[5];
    __uint128_t c = 0;
    
    // First reduction: res = low + high * 0x1000003D1
    for (int i = 0; i < 4; i++) {
        c += (__uint128_t)low[i] + (__uint128_t)high[i] * 0x1000003D1ULL;
        res[i] = (uint64_t)c;
        c >>= 64;
    }
    res[4] = (uint64_t)c;
    
    // Second reduction if needed
    c = 0;
    for (int i = 0; i < 4; i++) {
        c += (__uint128_t)res[i];
        if (i == 0) c += (__uint128_t)res[4] * 0x1000003D1ULL;
        res[i] = (uint64_t)c;
        c >>= 64;
    }
    res[4] = (uint64_t)c;
    
    // Third reduction if there is still carry
    if (res[4]) {
        c = (__uint128_t)res[0] + (__uint128_t)res[4] * 0x1000003D1ULL;
        res[0] = (uint64_t)c;
        c >>= 64;
        for (int i = 1; i < 4 && c; i++) {
            c += res[i];
            res[i] = (uint64_t)c;
            c >>= 64;
        }
    }
    
    for (int i = 0; i < 4; i++) r[i] = res[i];
    
    if (cmp256(r, SECP_P) >= 0) {
        sub256(r, r, SECP_P);
    }
}
// Modular inversion using Fermat's little theorem: a^(-1) = a^(p-2) mod p
static void mod_inv(uint64_t* r, const uint64_t* a) {
    uint64_t exp[4] = {
        0xFFFFFFFEFFFFFC2DULL, 0xFFFFFFFFFFFFFFFFULL,
        0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL
    };

    uint64_t base[4], result[4] = {1, 0, 0, 0};
    memcpy(base, a, 32);

    for (int i = 0; i < 256; i++) {
        if ((exp[i / 64] >> (i % 64)) & 1) {
            mod_mul(result, result, base);
        }
        mod_mul(base, base, base);
    }

    memcpy(r, result, 32);
}

// Check if point is at infinity
static int is_infinity(const uint64_t* x, const uint64_t* y) {
    return (x[0] | x[1] | x[2] | x[3] | y[0] | y[1] | y[2] | y[3]) == 0;
}

// Point addition: R = P + Q
static void point_add(uint64_t* rx, uint64_t* ry,
                      const uint64_t* px, const uint64_t* py,
                      const uint64_t* qx, const uint64_t* qy) {
    if (is_infinity(px, py)) {
        memcpy(rx, qx, 32); memcpy(ry, qy, 32); return;
    }
    if (is_infinity(qx, qy)) {
        memcpy(rx, px, 32); memcpy(ry, py, 32); return;
    }

    uint64_t s[4], dx[4], dy[4], s2[4], tmp[4];

    mod_sub(dx, qx, px);

    if ((dx[0] | dx[1] | dx[2] | dx[3]) == 0) {
        mod_sub(dy, qy, py);
        if ((dy[0] | dy[1] | dy[2] | dy[3]) == 0) {
            // P == Q, use point doubling formula
            mod_mul(s, px, px);
            mod_add(tmp, s, s);
            mod_add(s, tmp, s);  // s = 3*x^2
            mod_add(dy, py, py);
            mod_inv(tmp, dy);
            mod_mul(s, s, tmp);  // s = 3*x^2 / (2*y)
        } else {
            // P == -Q, result is infinity
            memset(rx, 0, 32); memset(ry, 0, 32); return;
        }
    } else {
        mod_sub(dy, qy, py);
        mod_inv(tmp, dx);
        mod_mul(s, dy, tmp);  // s = (qy - py) / (qx - px)
    }

    mod_mul(s2, s, s);
    mod_sub(rx, s2, px);
    mod_sub(rx, rx, qx);

    mod_sub(tmp, px, rx);
    mod_mul(ry, s, tmp);
    mod_sub(ry, ry, py);
}

// Point doubling: R = 2*P
static void point_double(uint64_t* rx, uint64_t* ry,
                         const uint64_t* px, const uint64_t* py) {
    if (is_infinity(px, py) || (py[0] | py[1] | py[2] | py[3]) == 0) {
        memset(rx, 0, 32); memset(ry, 0, 32); return;
    }

    uint64_t s[4], s2[4], tmp[4], dy[4];

    mod_mul(s, px, px);
    mod_add(tmp, s, s);
    mod_add(s, tmp, s);  // s = 3*x^2
    mod_add(dy, py, py);
    mod_inv(tmp, dy);
    mod_mul(s, s, tmp);  // s = 3*x^2 / (2*y)

    mod_mul(s2, s, s);
    mod_sub(rx, s2, px);
    mod_sub(rx, rx, px);

    mod_sub(tmp, px, rx);
    mod_mul(ry, s, tmp);
    mod_sub(ry, ry, py);
}

// Scalar multiplication: R = k * G
// =====================================================================================
// JACOBIAN COORDINATE ELLIPTIC CURVE OPERATIONS (faster - only 1 mod_inv at the end)
// =====================================================================================

// Jacobian point doubling: R = 2*P
// Cost: 4M + 4S (no division\!)
static void jacobian_double(uint64_t* x3, uint64_t* y3, uint64_t* z3,
                            const uint64_t* x1, const uint64_t* y1, const uint64_t* z1) {
    if ((z1[0] | z1[1] | z1[2] | z1[3]) == 0) {
        memset(x3, 0, 32); memset(y3, 0, 32); memset(z3, 0, 32);
        return;
    }
    
    uint64_t s[4], m[4], t[4], tmp[4], y1sq[4];
    
    mod_mul(y1sq, y1, y1);       // y1sq = Y1^2
    mod_mul(s, y1sq, x1);        // s = X1*Y1^2
    mod_add(s, s, s);            // s = 2*X1*Y1^2
    mod_add(s, s, s);            // s = 4*X1*Y1^2 (this is S)
    
    mod_mul(m, x1, x1);          // m = X1^2
    mod_add(tmp, m, m);          // tmp = 2*X1^2
    mod_add(m, tmp, m);          // m = 3*X1^2 (this is M, since a=0 for secp256k1)
    
    mod_mul(x3, m, m);           // x3 = M^2
    mod_add(tmp, s, s);          // tmp = 2*S
    mod_sub(x3, x3, tmp);        // x3 = M^2 - 2*S
    
    mod_sub(tmp, s, x3);         // tmp = S - X3
    mod_mul(y3, m, tmp);         // y3 = M*(S - X3)
    mod_mul(tmp, y1sq, y1sq);    // tmp = Y1^4
    mod_add(tmp, tmp, tmp);      // tmp = 2*Y1^4
    mod_add(tmp, tmp, tmp);      // tmp = 4*Y1^4
    mod_add(tmp, tmp, tmp);      // tmp = 8*Y1^4
    mod_sub(y3, y3, tmp);        // y3 = M*(S - X3) - 8*Y1^4
    
    mod_mul(z3, y1, z1);         // z3 = Y1*Z1
    mod_add(z3, z3, z3);         // z3 = 2*Y1*Z1
}

// Jacobian mixed addition: R = P(Jacobian) + Q(Affine)
// Cost: 8M + 3S (no division\!)
static void jacobian_add_affine(uint64_t* x3, uint64_t* y3, uint64_t* z3,
                                const uint64_t* x1, const uint64_t* y1, const uint64_t* z1,
                                const uint64_t* x2, const uint64_t* y2) {
    if ((z1[0] | z1[1] | z1[2] | z1[3]) == 0) {
        memcpy(x3, x2, 32); memcpy(y3, y2, 32);
        uint64_t one[4] = {1, 0, 0, 0};
        memcpy(z3, one, 32);
        return;
    }
    
    uint64_t z1z1[4], u2[4], s2[4], h[4], hh[4], i[4], j[4], r[4], v[4], tmp[4];
    
    mod_mul(z1z1, z1, z1);       // Z1Z1 = Z1^2
    mod_mul(u2, x2, z1z1);       // U2 = X2*Z1Z1
    mod_mul(s2, z1, z1z1);       // s2 = Z1^3
    mod_mul(s2, s2, y2);         // S2 = Y2*Z1^3
    
    mod_sub(h, u2, x1);          // H = U2 - X1
    
    if ((h[0] | h[1] | h[2] | h[3]) == 0) {
        mod_sub(tmp, s2, y1);
        if ((tmp[0] | tmp[1] | tmp[2] | tmp[3]) == 0) {
            jacobian_double(x3, y3, z3, x1, y1, z1);
            return;
        } else {
            memset(x3, 0, 32); memset(y3, 0, 32); memset(z3, 0, 32);
            return;
        }
    }
    
    mod_add(i, h, h);            // i = 2*H
    mod_mul(i, i, i);            // I = (2*H)^2
    mod_mul(j, h, i);            // J = H*I
    mod_sub(r, s2, y1);          // r = S2 - Y1
    mod_add(r, r, r);            // r = 2*(S2 - Y1)
    mod_mul(v, x1, i);           // V = X1*I
    
    mod_mul(x3, r, r);           // x3 = r^2
    mod_sub(x3, x3, j);          // x3 = r^2 - J
    mod_add(tmp, v, v);          // tmp = 2*V
    mod_sub(x3, x3, tmp);        // X3 = r^2 - J - 2*V
    
    mod_sub(tmp, v, x3);         // tmp = V - X3
    mod_mul(y3, r, tmp);         // y3 = r*(V - X3)
    mod_mul(tmp, y1, j);         // tmp = Y1*J
    mod_add(tmp, tmp, tmp);      // tmp = 2*Y1*J
    mod_sub(y3, y3, tmp);        // Y3 = r*(V - X3) - 2*Y1*J
    
    mod_mul(z3, z1, h);          // z3 = Z1*H
    mod_add(z3, z3, z3);         // Z3 = 2*Z1*H
}

// Convert Jacobian to Affine (single mod_inv\!)
static void jacobian_to_affine(uint64_t* ax, uint64_t* ay,
                               const uint64_t* jx, const uint64_t* jy, const uint64_t* jz) {
    if ((jz[0] | jz[1] | jz[2] | jz[3]) == 0) {
        memset(ax, 0, 32); memset(ay, 0, 32);
        return;
    }
    uint64_t zinv[4], zinv2[4], zinv3[4];
    mod_inv(zinv, jz);
    mod_mul(zinv2, zinv, zinv);
    mod_mul(zinv3, zinv2, zinv);
    mod_mul(ax, jx, zinv2);
    mod_mul(ay, jy, zinv3);
}

// Fast scalar multiplication using Jacobian coordinates
// Only 1 mod_inv at the very end\!
static void scalar_mult_G(uint64_t* rx, uint64_t* ry, const uint64_t* k) {
    uint64_t jx[4] = {0}, jy[4] = {0}, jz[4] = {0};
    uint64_t tmpx[4], tmpy[4], tmpz[4];
    
    // Process from MSB to LSB (double-and-add)
    for (int i = 255; i >= 0; i--) {
        jacobian_double(tmpx, tmpy, tmpz, jx, jy, jz);
        memcpy(jx, tmpx, 32); memcpy(jy, tmpy, 32); memcpy(jz, tmpz, 32);
        
        if ((k[i / 64] >> (i % 64)) & 1) {
            jacobian_add_affine(tmpx, tmpy, tmpz, jx, jy, jz, SECP_GX, SECP_GY);
            memcpy(jx, tmpx, 32); memcpy(jy, tmpy, 32); memcpy(jz, tmpz, 32);
        }
    }
    
    jacobian_to_affine(rx, ry, jx, jy, jz);
}


// =====================================================================================
// KEY PARSING FUNCTIONS
// =====================================================================================

// Convert decimal string to 256-bit integer. Strict: returns false on any
// non-digit character (other than user-friendly separators ',', '_', ' ')
// and on overflow past 2^256.
static bool decimal_to_256bit_strict(const char* decimal, uint64_t* result) {
    memset(result, 0, 32);
    if (!decimal || !*decimal) return false;

    bool saw_digit = false;
    for (int i = 0; decimal[i]; i++) {
        char c = decimal[i];
        if (c == ',' || c == '_' || c == ' ' || c == '\t') continue;  // separators OK
        if (c < '0' || c > '9') return false;
        saw_digit = true;

        // result = result * 10
        __uint128_t carry = 0;
        for (int k = 0; k < 4; k++) {
            __uint128_t prod = (__uint128_t)result[k] * 10 + carry;
            result[k] = (uint64_t)prod;
            carry = prod >> 64;
        }
        if (carry) return false;  // overflow past 2^256

        // result += digit
        carry = (uint64_t)(c - '0');
        for (int k = 0; k < 4 && carry; k++) {
            __uint128_t sum = (__uint128_t)result[k] + carry;
            result[k] = (uint64_t)sum;
            carry = sum >> 64;
        }
        if (carry) return false;  // overflow past 2^256
    }
    return saw_digit;
}

// Legacy non-strict parser, kept for the -bits shortcut path.
static void decimal_to_256bit(const char* decimal, uint64_t* result) {
    memset(result, 0, 32);

    // Skip any commas/underscores in the input (user-friendly format)
    char clean[256];
    int j = 0;
    for (int i = 0; decimal[i] && j < 255; i++) {
        if (decimal[i] >= '0' && decimal[i] <= '9') {
            clean[j++] = decimal[i];
        }
    }
    clean[j] = '\0';

    // Process each digit: result = result * 10 + digit
    for (int i = 0; clean[i]; i++) {
        // Multiply by 10
        __uint128_t carry = 0;
        for (int k = 0; k < 4; k++) {
            __uint128_t prod = (__uint128_t)result[k] * 10 + carry;
            result[k] = (uint64_t)prod;
            carry = prod >> 64;
        }

        // Add digit
        int digit = clean[i] - '0';
        carry = digit;
        for (int k = 0; k < 4 && carry; k++) {
            __uint128_t sum = (__uint128_t)result[k] + carry;
            result[k] = (uint64_t)sum;
            carry = sum >> 64;
        }
    }
}

// Convert hex string to 256-bit integer. Strict: returns false on any
// non-hex character or if the value exceeds 256 bits. Accepts optional
// "0x"/"0X" prefix. Empty input is rejected.
static bool hex_to_256bit_strict(const char* hex, uint64_t* result) {
    memset(result, 0, 32);
    if (!hex) return false;

    if (hex[0] == '0' && (hex[1] == 'x' || hex[1] == 'X')) hex += 2;
    if (*hex == '\0') return false;

    int len = (int)strlen(hex);
    if (len > 64) return false;  // > 256 bits

    uint8_t* bytes = (uint8_t*)result;
    for (int i = 0; i < len; i++) {
        char c = hex[len - 1 - i];
        int val;
        if      (c >= '0' && c <= '9') val = c - '0';
        else if (c >= 'a' && c <= 'f') val = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') val = c - 'A' + 10;
        else return false;  // strict: no silent skip

        int byteIdx = i / 2;
        if (i % 2 == 0) bytes[byteIdx]  = (uint8_t)val;
        else            bytes[byteIdx] |= (uint8_t)(val << 4);
    }
    return true;
}

// Legacy non-strict parser, kept for the -bits shortcut that builds its own
// guaranteed-valid hex string. User-facing flags go through _strict instead.
static void hex_to_256bit(const char* hex, uint64_t* result) {
    memset(result, 0, 32);

    // Skip 0x prefix
    if (hex[0] == '0' && (hex[1] == 'x' || hex[1] == 'X')) {
        hex += 2;
    }

    int len = strlen(hex);
    uint8_t* bytes = (uint8_t*)result;

    // Parse from right to left (little-endian)
    for (int i = 0; i < len && i < 64; i++) {
        char c = hex[len - 1 - i];
        int val;
        if (c >= '0' && c <= '9') val = c - '0';
        else if (c >= 'a' && c <= 'f') val = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') val = c - 'A' + 10;
        else continue;

        int byteIdx = i / 2;
        if (i % 2 == 0) {
            bytes[byteIdx] = val;
        } else {
            bytes[byteIdx] |= val << 4;
        }
    }
}

// Format 256-bit as hex string
static void format_256bit_hex(const uint64_t* val, char* out) {
    sprintf(out, "%016lx%016lx%016lx%016lx", val[3], val[2], val[1], val[0]);
}

// =====================================================================================
// GPU KERNEL CODE
// =====================================================================================

// GPU Base58 address generation (from VanitySearch)
__device__ __noinline__ void _GetAddress(int type, uint32_t *hash, char *b58Add) {
    uint32_t addBytes[16];
    uint32_t s[16];
    unsigned char A[25];
    unsigned char *addPtr = A;
    int retPos = 0;
    unsigned char digits[128];

    A[0] = (type == P2PKH) ? 0x00 : 0x05;
    memcpy(A + 1, (char *)hash, 20);

    addBytes[0] = __byte_perm(hash[0], (uint32_t)A[0], 0x4012);
    addBytes[1] = __byte_perm(hash[0], hash[1], 0x3456);
    addBytes[2] = __byte_perm(hash[1], hash[2], 0x3456);
    addBytes[3] = __byte_perm(hash[2], hash[3], 0x3456);
    addBytes[4] = __byte_perm(hash[3], hash[4], 0x3456);
    addBytes[5] = __byte_perm(hash[4], 0x80, 0x3456);
    addBytes[6] = 0; addBytes[7] = 0; addBytes[8] = 0; addBytes[9] = 0;
    addBytes[10] = 0; addBytes[11] = 0; addBytes[12] = 0; addBytes[13] = 0;
    addBytes[14] = 0; addBytes[15] = 0xA8;

    SHA256Initialize(s);
    SHA256Transform(s, addBytes);

    #pragma unroll 8
    for (int i = 0; i < 8; i++) addBytes[i] = s[i];

    addBytes[8] = 0x80000000; addBytes[9] = 0; addBytes[10] = 0; addBytes[11] = 0;
    addBytes[12] = 0; addBytes[13] = 0; addBytes[14] = 0; addBytes[15] = 0x100;

    SHA256Initialize(s);
    SHA256Transform(s, addBytes);

    A[21] = ((uint8_t *)s)[3];
    A[22] = ((uint8_t *)s)[2];
    A[23] = ((uint8_t *)s)[1];
    A[24] = ((uint8_t *)s)[0];

    while (addPtr[0] == 0) {
        b58Add[retPos++] = 0x31;  // ASCII '1' - use explicit hex to avoid CUDA char literal issues
        addPtr++;
    }
    int length = 25 - retPos;

    int digitslen = 1;
    digits[0] = 0;
    for (int i = 0; i < length; i++) {
        uint32_t carry = addPtr[i];
        for (int j = 0; j < digitslen; j++) {
            carry += (uint32_t)(digits[j]) << 8;
            digits[j] = (unsigned char)(carry % 58);
            carry /= 58;
        }
        while (carry > 0) {
            digits[digitslen++] = (unsigned char)(carry % 58);
            carry /= 58;
        }
    }

    for (int i = 0; i < digitslen; i++)
        b58Add[retPos++] = pszBase58[digits[digitslen - 1 - i]];

    b58Add[retPos] = 0;
}

__device__ __noinline__ bool _MatchPrefix(const char *addr, const char *pattern, int patLen) {
    for (int i = 0; i < patLen; i++) {
        if (addr[i] != pattern[i]) return false;
    }
    return true;
}

// Hash160-direct match: compare the 20 raw bytes from _GetHash160CompSym against
// the precomputed targets in constant memory. Much cheaper than Base58 + strcmp
// because we skip Base58 entirely. 'h' is 5 uint32 words (20 bytes).
__device__ __forceinline__ int _MatchHash160(const uint32_t *h) {
    #pragma unroll 1
    for (int i = 0; i < d_num_targets; i++) {
        if (h[0] == d_target_h160[i][0] &&
            h[1] == d_target_h160[i][1] &&
            h[2] == d_target_h160[i][2] &&
            h[3] == d_target_h160[i][3] &&
            h[4] == d_target_h160[i][4]) {
            return i;
        }
    }
    return -1;
}

__device__ bool CheckVanityPatternsK4(uint32_t *h, int *matched_idx, char *gen_addr) {
    _GetAddress(P2PKH, h, gen_addr);
    for (int i = 0; i < d_num_patterns; i++) {
        if (_MatchPrefix(gen_addr, d_patterns[i], d_pattern_lens[i])) {
            *matched_idx = i;
            return true;
        }
    }
    *matched_idx = -1;
    return false;
}

__device__ void OutputMatchK4(uint32_t* out, uint32_t tid, int32_t incr, uint32_t* h, int pattern_idx, uint8_t isOdd) {
    uint32_t pos = atomicAdd(out, 1);
    if (pos < MAX_FOUND) {
        uint32_t* entry = out + 1 + pos * 8;
        entry[0] = tid;          // Thread ID for key reconstruction
        entry[1] = (uint32_t)incr;
        entry[2] = (pattern_idx << 8) | isOdd;
        entry[3] = h[0];
        entry[4] = h[1];
        entry[5] = h[2];
        entry[6] = h[3];
        entry[7] = h[4];
    }
}

// Check compressed addresses (uses symmetry - both Y and -Y checked)
// In legacy prefix-match mode, also checks uncompressed addresses.
// In hash160-direct mode (d_direct_mode != 0), uncompressed is skipped and
// Base58 is never invoked in the hot path — direct 20-byte hash compare.
__device__ __noinline__ void CheckHashCompSymK4(
    uint64_t* px, uint64_t* py, uint32_t tid, int32_t incr,
    uint32_t maxFound, uint32_t* out
) {
    uint32_t h1[5], h2[5];
    int matched_idx;

    // Both Y-parity compressed hashes, computed by one call.
    _GetHash160CompSym(px, (uint8_t*)h1, (uint8_t*)h2);

    if (d_direct_mode) {
        // Hash160-direct mode: skip Base58, skip uncompressed.
        matched_idx = _MatchHash160(h1);
        if (matched_idx >= 0) OutputMatchK4(out, tid, incr, h1, matched_idx, 0);
        matched_idx = _MatchHash160(h2);
        if (matched_idx >= 0) OutputMatchK4(out, tid, -incr, h2, matched_idx, 1);
        return;
    }

    // Legacy prefix-match mode: generate Base58 and compare prefixes,
    // also check both uncompressed variants (Y and -Y).
    char addr[40];
    uint32_t h_uncomp1[5], h_uncomp2[5];

    if (CheckVanityPatternsK4(h1, &matched_idx, addr)) {
        OutputMatchK4(out, tid, incr, h1, matched_idx, 0);
    }
    if (CheckVanityPatternsK4(h2, &matched_idx, addr)) {
        OutputMatchK4(out, tid, -incr, h2, matched_idx, 1);
    }

    _GetHash160(px, py, (uint8_t*)h_uncomp1);
    if (CheckVanityPatternsK4(h_uncomp1, &matched_idx, addr)) {
        OutputMatchK4(out, tid, incr, h_uncomp1, matched_idx, 2);
    }

    uint64_t negY[4];
    ModNeg256(negY, py);
    _GetHash160(px, negY, (uint8_t*)h_uncomp2);
    if (CheckVanityPatternsK4(h_uncomp2, &matched_idx, addr)) {
        OutputMatchK4(out, tid, -incr, h_uncomp2, matched_idx, 3);
    }
}

__device__ void ComputeKeysK4(
    uint64_t* dx_global, uint64_t* subp_global,
    uint32_t mode, uint64_t* startx, uint64_t* starty,
    uint32_t maxFound, uint32_t* out
) {
    // Cast global memory to 2D array pointers for dx and subp
    // These are allocated per-thread in global memory to avoid stack overflow
    uint64_t (*dx)[4] = (uint64_t (*)[4])dx_global;
    uint64_t (*subp)[4] = (uint64_t (*)[4])subp_global;

    uint64_t px[4], py[4], pyn[4], sx[4], sy[4], dy[4], _s[4], _p2[4];

    uint32_t tid = blockIdx.x * blockDim.x + threadIdx.x;

    __syncthreads();
    Load256A(sx, startx);
    Load256A(sy, starty);
    Load256(px, sx);
    Load256(py, sy);

    for (uint32_t j = 0; j < STEP_SIZE / GRP_SIZE; j++) {
        uint32_t i;
        for (i = 0; i < HSIZE; i++)
            ModSub256(dx[i], Gx[i], sx);
        ModSub256(dx[i], Gx[i], sx);
        ModSub256(dx[i+1], _2Gnx, sx);

        _ModInvGrouped(dx, subp);

        CheckHashCompSymK4(px, py, tid, j*GRP_SIZE + GRP_SIZE/2, maxFound, out);

        ModNeg256(pyn, py);

        for (i = 0; i < HSIZE; i++) {
            Load256(px, sx);
            Load256(py, sy);
            ModSub256(dy, Gy[i], py);
            _ModMult(_s, dy, dx[i]);
            _ModSqr(_p2, _s);
            ModSub256(px, _p2, px);
            ModSub256(px, Gx[i]);
            ModSub256(py, Gx[i], px);
            _ModMult(py, _s);
            ModSub256(py, Gy[i]);

            CheckHashCompSymK4(px, py, tid, j*GRP_SIZE + GRP_SIZE/2 + (i+1), maxFound, out);

            Load256(px, sx);
            ModSub256(dy, pyn, Gy[i]);
            _ModMult(_s, dy, dx[i]);
            _ModSqr(_p2, _s);
            ModSub256(px, _p2, px);
            ModSub256(px, Gx[i]);
            ModSub256(py, Gx[i], px);
            _ModMult(py, _s);
            ModSub256(py, Gy[i]);
            ModNeg256(py, py);

            CheckHashCompSymK4(px, py, tid, j*GRP_SIZE + GRP_SIZE/2 - (i+1), maxFound, out);
        }

        Load256(px, sx);
        Load256(py, sy);
        ModNeg256(dy, Gy[i]);
        ModSub256(dy, py);
        _ModMult(_s, dy, dx[i]);
        _ModSqr(_p2, _s);
        ModSub256(px, _p2, px);
        ModSub256(px, Gx[i]);
        ModSub256(py, Gx[i], px);
        _ModMult(py, _s);
        ModSub256(py, Gy[i]);
        ModNeg256(py, py);
        CheckHashCompSymK4(px, py, tid, j*GRP_SIZE, maxFound, out);

        i++;
        Load256(px, sx);
        Load256(py, sy);
        ModSub256(dy, _2Gny, py);
        _ModMult(_s, dy, dx[i]);
        _ModSqr(_p2, _s);
        ModSub256(px, _p2, px);
        ModSub256(px, _2Gnx);
        ModSub256(py, _2Gnx, px);
        _ModMult(py, _s);
        ModSub256(py, _2Gny);
    }

    // For sequential mode: advance by the additional delta to reach (nbThread * STEP_SIZE) * G
    // The loop above already advanced by STEP_SIZE * G = _2Gn
    // Now add the extra (nbThread - 1) * STEP_SIZE * G from d_seqDelta
    if (d_useSeqDelta) {
        // Point addition: (px, py) = (px, py) + (d_seqDeltaX, d_seqDeltaY)
        // Using standard EC point addition formula
        uint64_t dxSeq[4], dySeq[4], sSeq[4], s2Seq[4], rxSeq[4], rySeq[4];

        // dx = deltaX - px
        ModSub256(dxSeq, d_seqDeltaX, px);

        // dy = deltaY - py
        ModSub256(dySeq, d_seqDeltaY, py);

        // s = dy / dx (need modular inverse of dx)
        // _ModInv operates on a 320-bit extended value and inverts in place
        uint64_t invDx[5];  // 320 bits for _ModInv
        Load256(invDx, dxSeq);
        invDx[4] = 0;
        _ModInv(invDx);
        _ModMult(sSeq, dySeq, invDx);

        // s^2
        _ModSqr(s2Seq, sSeq);

        // rx = s^2 - px - deltaX
        ModSub256(rxSeq, s2Seq, px);
        ModSub256(rxSeq, d_seqDeltaX);

        // ry = s * (px - rx) - py
        ModSub256(rySeq, px, rxSeq);
        _ModMult(rySeq, sSeq, rySeq);
        ModSub256(rySeq, py);

        Load256(px, rxSeq);
        Load256(py, rySeq);
    }

    __syncthreads();
    Store256A(startx, px);
    Store256A(starty, py);
}

__global__ void searchK4_kernel(
    uint64_t* dx_buffer, uint64_t* subp_buffer,
    uint32_t mode, uint64_t* keys,
    uint32_t maxFound, uint32_t* found
) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    int xPtr = (blockIdx.x * blockDim.x) * 8;
    int yPtr = xPtr + 4 * NB_THREAD_PER_GROUP;

    // Each thread gets its own slice of the global dx and subp buffers
    // Array size per thread: (GRP_SIZE/2+1) * 4 uint64_t values
    size_t arraySize = (GRP_SIZE / 2 + 1) * 4;
    uint64_t* my_dx = dx_buffer + tid * arraySize;
    uint64_t* my_subp = subp_buffer + tid * arraySize;

    ComputeKeysK4(my_dx, my_subp, mode, keys + xPtr, keys + yPtr, maxFound, found);
}

// =====================================================================================
// HOST UTILITY FUNCTIONS
// =====================================================================================

void secure_random(void* buf, size_t len) {
    FILE* f = fopen("/dev/urandom", "rb");
    if (f) { fread(buf, 1, len, f); fclose(f); }
}

// State file format for sequential mode.
//
// v3 layout (current):
//   [8  bytes: magic "SK4STv03"]
//   [8  bytes: total keys covered]
//   [8  bytes: iter counter at save time]   <-- NEW in v3
//   [32 bytes: base key]
//   [4  bytes: nbThread at save time]
//   [4  bytes: reserved/pad]
//   [keys data: nbThread * 64 bytes]
//
// v2 layout (accepted on load, no iter): same as v3 without the iter field.
// v1 layout (accepted on load): [8B total] [32B base key] [keys data].
//
// CRITICAL: `iter` must round-trip across save/resume. reconstruct_privkey()
// uses (iter * nbThread * STEP_SIZE) as the per-thread iteration offset. If
// iter is reset to 0 on resume, any match found in the first post-resume
// iteration will be written with a wrong private key — off by exactly
// (saved_iter * nbThread * STEP_SIZE) from the real answer.
static const char SK4_STATE_MAGIC_V3[8] = {'S','K','4','S','T','v','0','3'};
static const char SK4_STATE_MAGIC_V2[8] = {'S','K','4','S','T','v','0','2'};

void save_state_seq(const char* f, uint64_t* k, int n, uint64_t t,
                    uint64_t iter, const uint64_t* baseKey) {
    FILE* fp = fopen(f, "wb");
    if (!fp) return;
    fwrite(SK4_STATE_MAGIC_V3, 1, 8, fp);
    fwrite(&t, 8, 1, fp);
    fwrite(&iter, 8, 1, fp);
    fwrite(baseKey, 8, 4, fp);
    uint32_t nbt = (uint32_t)n;
    uint32_t pad = 0;
    fwrite(&nbt, 4, 1, fp);
    fwrite(&pad, 4, 1, fp);
    fwrite(k, 8, n*8, fp);
    fclose(fp);
}

// Returns total keys covered, or 0 on failure.
// Writes nbThread into *out_nbThread if present in the file (v2, v3).
// Writes iter into *out_iter if present (v3 only); left at 0 for v1/v2.
uint64_t load_state_seq(const char* f, uint64_t* k, int n, uint64_t* baseKey,
                        int* out_nbThread, uint64_t* out_iter) {
    struct stat st;
    if (stat(f, &st)) return 0;
    FILE* fp = fopen(f, "rb");
    if (!fp) return 0;

    char hdr[8] = {0};
    if (fread(hdr, 1, 8, fp) != 8) { fclose(fp); return 0; }
    uint64_t t = 0;

    if (memcmp(hdr, SK4_STATE_MAGIC_V3, 8) == 0) {
        // v3: adds iter between total and baseKey.
        uint64_t iter = 0;
        if (fread(&t,    8, 1, fp) != 1) { fclose(fp); return 0; }
        if (fread(&iter, 8, 1, fp) != 1) { fclose(fp); return 0; }
        if (fread(baseKey, 8, 4, fp) != 4) { fclose(fp); return 0; }
        uint32_t nbt = 0, pad = 0;
        if (fread(&nbt, 4, 1, fp) != 1) { fclose(fp); return 0; }
        if (fread(&pad, 4, 1, fp) != 1) { fclose(fp); return 0; }
        if (out_nbThread) *out_nbThread = (int)nbt;
        if (out_iter)     *out_iter = iter;
        if (fread(k, 8, n*8, fp) != (size_t)(n*8)) { fclose(fp); return 0; }
    } else if (memcmp(hdr, SK4_STATE_MAGIC_V2, 8) == 0) {
        // v2: no iter field. Caller is responsible for knowing that
        // reconstructing keys on the first post-resume match may be off.
        if (fread(&t, 8, 1, fp) != 1) { fclose(fp); return 0; }
        if (fread(baseKey, 8, 4, fp) != 4) { fclose(fp); return 0; }
        uint32_t nbt = 0, pad = 0;
        if (fread(&nbt, 4, 1, fp) != 1) { fclose(fp); return 0; }
        if (fread(&pad, 4, 1, fp) != 1) { fclose(fp); return 0; }
        if (out_nbThread) *out_nbThread = (int)nbt;
        if (out_iter)     *out_iter = 0;  /* unknown */
        if (fread(k, 8, n*8, fp) != (size_t)(n*8)) { fclose(fp); return 0; }
        fprintf(stderr, "[warn] v2 state file: iter not stored; post-resume matches may mis-reconstruct.\n");
    } else {
        // v1: first 8 bytes we read are actually `t`.
        memcpy(&t, hdr, 8);
        if (fread(baseKey, 8, 4, fp) != 4) { fclose(fp); return 0; }
        if (fread(k, 8, n*8, fp) != (size_t)(n*8)) { fclose(fp); return 0; }
        if (out_iter) *out_iter = 0;
        fprintf(stderr, "[warn] v1 state file: nbThread + iter not stored.\n");
    }
    fclose(fp);
    return t;
}

// Legacy state format (random mode)
void save_state(const char* f, uint64_t* k, int n, uint64_t t) {
    FILE* fp = fopen(f, "wb");
    if (fp) { fwrite(&t, 8, 1, fp); fwrite(k, 8, n*8, fp); fclose(fp); }
}

uint64_t load_state(const char* f, uint64_t* k, int n) {
    struct stat st;
    if (stat(f, &st)) return 0;
    FILE* fp = fopen(f, "rb");
    if (!fp) return 0;
    uint64_t t = 0;
    if (fread(&t, 8, 1, fp) != 1) { fclose(fp); return 0; }
    if (fread(k, 8, n*8, fp) != (size_t)(n*8)) { fclose(fp); return 0; }
    fclose(fp);
    return t;
}

// Initialize keys sequentially from a starting point
// Optimized: compute baseKey*G once, then add G repeatedly for sequential keys
// =====================================================================================
// FAST KEY INITIALIZATION using Montgomery batch inversion + precomputed G table
// =====================================================================================

// Montgomery batch inversion: given [a0, a1, ..., an-1], compute [a0^-1, a1^-1, ..., an-1^-1]
// Uses (3n-3) multiplications + 1 inversion instead of n inversions.
//
// Precondition: all inputs are non-zero mod p. If any input is zero, the
// product chain has a zero in it, inv_total is a bogus inverse-of-zero, and
// the whole output array is garbage with no signal to the caller. We scan
// for that case first and bail out loudly — practically unreachable for
// puzzle inputs (it would require baseKey ≡ ±(t * STEP_SIZE) mod N for some
// t < nbThread, which means baseKey < nbThread*STEP_SIZE ≈ 2^24, vs the
// puzzle ranges of 2^70+), but silent corruption is not an acceptable
// failure mode for a key-search tool.
static void batch_mod_inv(uint64_t* results, uint64_t* inputs, int n) {
    if (n == 0) return;
    if (n == 1) {
        mod_inv(results, inputs);
        return;
    }

    for (int i = 0; i < n; i++) {
        const uint64_t* a = &inputs[i * 4];
        if ((a[0] | a[1] | a[2] | a[3]) == 0) {
            fprintf(stderr,
                "FATAL: batch_mod_inv got zero at index %d of %d — "
                "start key collides with i*G for some i in thread spacing. "
                "Choose a different start key.\n", i, n);
            exit(1);
        }
    }

    uint64_t* partials = (uint64_t*)malloc(n * 32);
    
    memcpy(&partials[0], &inputs[0], 32);
    for (int i = 1; i < n; i++) {
        mod_mul(&partials[i * 4], &partials[(i-1) * 4], &inputs[i * 4]);
    }
    
    uint64_t inv_total[4];
    mod_inv(inv_total, &partials[(n-1) * 4]);
    
    uint64_t running_inv[4];
    memcpy(running_inv, inv_total, 32);
    
    for (int i = n - 1; i > 0; i--) {
        mod_mul(&results[i * 4], running_inv, &partials[(i-1) * 4]);
        uint64_t tmp[4];
        mod_mul(tmp, running_inv, &inputs[i * 4]);
        memcpy(running_inv, tmp, 32);
    }
    memcpy(&results[0], running_inv, 32);
    
    free(partials);
}

// Get i*G using precomputed table
static void get_iG(uint64_t* rx, uint64_t* ry, uint64_t i) {
    if (i == 0) {
        memset(rx, 0, 32);
        memset(ry, 0, 32);
        return;
    }
    if (i <= CPU_GRP_SIZE) {
        memcpy(rx, Gx_cpu[i-1], 32);
        memcpy(ry, Gy_cpu[i-1], 32);
        return;
    }
    uint64_t k[4] = {i, 0, 0, 0};
    scalar_mult_G(rx, ry, k);
}

// Compute and upload sequential-advance delta = (nbThread-1) * STEP_SIZE * G.
// Safe to call from both the fresh-init path and the state-resume path.
// Also enables d_useSeqDelta on the device.
static void upload_seq_delta(int nbThread) {
    uint64_t delta_scalar[4] = {0, 0, 0, 0};
    uint64_t delta_val = (uint64_t)(nbThread - 1) * STEP_SIZE;
    delta_scalar[0] = delta_val;

    uint64_t seqDeltaX[4], seqDeltaY[4];
    scalar_mult_G(seqDeltaX, seqDeltaY, delta_scalar);

    cudaError_t err;
    err = cudaMemcpyToSymbol(d_seqDeltaX, seqDeltaX, 32);
    if (err != cudaSuccess) {
        printf("CUDA ERROR copying seqDeltaX: %s\n", cudaGetErrorString(err));
    }
    err = cudaMemcpyToSymbol(d_seqDeltaY, seqDeltaY, 32);
    if (err != cudaSuccess) {
        printf("CUDA ERROR copying seqDeltaY: %s\n", cudaGetErrorString(err));
    }
    int useSeq = (nbThread > 1) ? 1 : 0;
    err = cudaMemcpyToSymbol(d_useSeqDelta, &useSeq, sizeof(int));
    if (err != cudaSuccess) {
        printf("CUDA ERROR copying useSeqDelta: %s\n", cudaGetErrorString(err));
    }
}

void init_keys_from_start(uint64_t* h_keys, int nbThread, const char* startStr, bool isHex) {
    printf("Initializing %d threads for SEQUENTIAL range search...\n", nbThread);

    if (isHex) hex_to_256bit(startStr, g_baseKey);
    else decimal_to_256bit(startStr, g_baseKey);

    char hexStr[65];
    format_256bit_hex(g_baseKey, hexStr);
    printf("  Start: 0x%s\n", hexStr);

    // PROPER SEQUENTIAL RANGE SEARCH:
    // - Space threads STEP_SIZE (1024) apart for non-overlapping coverage
    // - Thread 0: keys [0, 1024), [nbThread*1024, nbThread*1024+1024), ...
    // - Thread 1: keys [1024, 2048), [nbThread*1024+1024, ...], ...
    // - Per iteration: keys [iter*nbThread*STEP_SIZE, (iter+1)*nbThread*STEP_SIZE)
    //
    // The kernel internally advances each thread by STEP_SIZE.
    // We add an ADDITIONAL delta of (nbThread-1)*STEP_SIZE*G after each iteration
    // to make total advancement = nbThread * STEP_SIZE per thread.

    uint64_t p0x[4], p0y[4];
    printf("  Computing base point...\n"); fflush(stdout);
    scalar_mult_G(p0x, p0y, g_baseKey);

    // Store thread 0's starting point (key = baseKey)
    {
        int block = 0;
        int tidInBlock = 0;
        int blockBase = block * NB_THREAD_PER_GROUP * 8;
        int xBase = blockBase + tidInBlock;
        int yBase = blockBase + 4 * NB_THREAD_PER_GROUP + tidInBlock;
        for (int j = 0; j < 4; j++) {
            h_keys[xBase + j * NB_THREAD_PER_GROUP] = p0x[j];
            h_keys[yBase + j * NB_THREAD_PER_GROUP] = p0y[j];
        }
    }

    if (nbThread == 1) {
        printf("  Done (single thread)\n");
        g_sequentialMode = true;
        g_nbThread = nbThread;
        return;
    }

    const int BATCH_SIZE = 8192;
    int remaining = nbThread - 1;
    int processed = 1;

    uint64_t* dx_batch = (uint64_t*)malloc(BATCH_SIZE * 32);
    uint64_t* inv_batch = (uint64_t*)malloc(BATCH_SIZE * 32);
    uint64_t* iGx_batch = (uint64_t*)malloc(BATCH_SIZE * 32);
    uint64_t* iGy_batch = (uint64_t*)malloc(BATCH_SIZE * 32);

    time_t start_time = time(NULL);

    while (remaining > 0) {
        int batch = (remaining < BATCH_SIZE) ? remaining : BATCH_SIZE;

        for (int i = 0; i < batch; i++) {
            // Thread t at key baseKey + t*STEP_SIZE (spaced by STEP_SIZE for non-overlapping)
            uint64_t offset = (uint64_t)(processed + i) * STEP_SIZE;
            get_iG(&iGx_batch[i * 4], &iGy_batch[i * 4], offset);
            mod_sub(&dx_batch[i * 4], &iGx_batch[i * 4], p0x);
        }

        batch_mod_inv(inv_batch, dx_batch, batch);

        for (int i = 0; i < batch; i++) {
            int t = processed + i;

            uint64_t *iGx = &iGx_batch[i * 4];
            uint64_t *iGy = &iGy_batch[i * 4];
            uint64_t *inv_dx = &inv_batch[i * 4];

            uint64_t dy[4], s[4], s2[4], rx[4], ry[4], tmp[4];
            mod_sub(dy, iGy, p0y);
            mod_mul(s, dy, inv_dx);
            mod_mul(s2, s, s);
            mod_sub(rx, s2, p0x);
            mod_sub(rx, rx, iGx);
            mod_sub(tmp, p0x, rx);
            mod_mul(ry, s, tmp);
            mod_sub(ry, ry, p0y);

            // Store using GPU's strided memory layout
            int block = t / NB_THREAD_PER_GROUP;
            int tidInBlock = t % NB_THREAD_PER_GROUP;
            int blockBase = block * NB_THREAD_PER_GROUP * 8;
            int xBase = blockBase + tidInBlock;
            int yBase = blockBase + 4 * NB_THREAD_PER_GROUP + tidInBlock;

            for (int j = 0; j < 4; j++) {
                h_keys[xBase + j * NB_THREAD_PER_GROUP] = rx[j];
                h_keys[yBase + j * NB_THREAD_PER_GROUP] = ry[j];
            }
        }

        processed += batch;
        remaining -= batch;

        printf("\r  Generated %d/%d thread starting points...", processed, nbThread);
        fflush(stdout);
    }

    printf("\n  Freeing batch buffers...\n"); fflush(stdout);
    free(dx_batch);
    free(inv_batch);
    free(iGx_batch);
    free(iGy_batch);
    printf("  Buffers freed.\n"); fflush(stdout);

    double elapsed = difftime(time(NULL), start_time);
    if (elapsed < 1) elapsed = 1;
    printf("\n  Done! %d threads in %.1fs (%.0f threads/sec)\n", nbThread, elapsed, nbThread / elapsed);
    fflush(stdout);

    // Upload sequential-advance delta to device constants.
    upload_seq_delta(nbThread);

    uint64_t totalDelta = (uint64_t)nbThread * STEP_SIZE;
    printf("  Sequential mode: each iteration advances by %lu keys\n", totalDelta);

    g_sequentialMode = true;
    g_nbThread = nbThread;
}

// Reconstruct private key from match info
// parity: 0=even compressed, 1=odd compressed, 2=uncompressed, 3=uncompressed negated Y
void reconstruct_privkey(uint64_t* privkey, uint32_t tid, int32_t incr, uint64_t iter, uint8_t parity) {
    // SEQUENTIAL MODE with proper thread spacing:
    // - Thread tid starts at key baseKey + tid * STEP_SIZE
    // - Each iteration covers STEP_SIZE keys, then advances by nbThread * STEP_SIZE
    // - After iter iterations: thread is at key baseKey + tid*STEP_SIZE + iter*nbThread*STEP_SIZE
    //
    // The GPU checks compressed (02+X and 03+X) and uncompressed (04+X+Y) forms.
    // parity indicates which form matched: 0=even, 1=odd, 2=uncompressed, 3=uncompressed negated

    // For odd reported parity (compressed) or negated uncompressed, the kernel stored -incr
    // For uncompressed (parity=2), incr is not negated
    int32_t actualIncr = (parity == 1 || parity == 3) ? -incr : incr;

    // The kernel passes incr such that:
    //   actualIncr = GRP_SIZE/2 means offset 0 from starting point
    //   actualIncr = GRP_SIZE/2 + k means offset +k from starting point
    int32_t keyOffset = actualIncr - 512;  // 512 = GRP_SIZE/2

    // Formula: basePrivkey = baseKey + tid*STEP_SIZE + iter*nbThread*STEP_SIZE + keyOffset
    uint64_t basePrivkey[4] = {0, 0, 0, 0};

    // Add thread's starting offset: tid * STEP_SIZE
    uint64_t threadOffset = (uint64_t)tid * STEP_SIZE;
    add256_scalar(basePrivkey, g_baseKey, threadOffset);

    // Add iteration offset: iter * nbThread * STEP_SIZE
    // This is a 256-bit multiplication since it can be large
    uint64_t keysPerIter = (uint64_t)g_nbThread * STEP_SIZE;
    // For iter up to ~2^32 and keysPerIter = 67M, product fits in 64 bits... actually no.
    // iter * 67M can overflow 64-bit for large iter. Need to handle this carefully.
    // For now, iter is usually small (< 2^32), and keysPerIter is ~67M, so product is ~2^56
    // But for safety, let's do proper 128-bit arithmetic
    __uint128_t iterOffset128 = (__uint128_t)iter * keysPerIter;
    uint64_t iterOffsetLo = (uint64_t)iterOffset128;
    uint64_t iterOffsetHi = (uint64_t)(iterOffset128 >> 64);
    uint64_t iterOffsetArr[4] = {iterOffsetLo, iterOffsetHi, 0, 0};
    add256(basePrivkey, basePrivkey, iterOffsetArr);

    // Add keyOffset (can be negative)
    if (keyOffset >= 0) {
        add256_scalar(basePrivkey, basePrivkey, (uint64_t)keyOffset);
    } else {
        uint64_t negOffset = (uint64_t)(-keyOffset);
        uint64_t tmp[4] = {negOffset, 0, 0, 0};
        sub256(basePrivkey, basePrivkey, tmp);
    }

    // For uncompressed addresses with normal Y, use the key directly
    if (parity == 2) {
        memcpy(privkey, basePrivkey, 32);
        return;
    }

    // For uncompressed addresses with negated Y, negate the key mod N
    if (parity == 3) {
        sub256(privkey, SECP_N, basePrivkey);
        return;
    }

    // For compressed: Compute Y parity of basePrivkey * G
    uint64_t px[4], py[4];
    scalar_mult_G(px, py, basePrivkey);
    bool actualYOdd = (py[0] & 1) != 0;
    bool reportedOdd = (parity == 1);

    // If actual Y parity matches reported parity, use basePrivkey
    // Otherwise, use N - basePrivkey
    if (actualYOdd == reportedOdd) {
        memcpy(privkey, basePrivkey, 32);
    } else {
        // Negate mod N (the curve order): privkey = N - basePrivkey
        sub256(privkey, SECP_N, basePrivkey);
    }
}

// Base58 encoding for WIF
static const char b58_alphabet[] = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

// Host-side SHA256 for checksum calculation (must be defined before functions that use it)
static void sha256_host(const uint8_t* data, size_t len, uint8_t* hash) {
    uint32_t h[8] = {
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    };

    static const uint32_t k[64] = {
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
        0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
        0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
        0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
        0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
        0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
        0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    };

    // Pad message
    uint8_t padded[128];
    memset(padded, 0, 128);
    memcpy(padded, data, len);
    padded[len] = 0x80;

    size_t padded_len = ((len + 9 + 63) / 64) * 64;
    uint64_t bit_len = len * 8;
    padded[padded_len - 8] = (bit_len >> 56) & 0xFF;
    padded[padded_len - 7] = (bit_len >> 48) & 0xFF;
    padded[padded_len - 6] = (bit_len >> 40) & 0xFF;
    padded[padded_len - 5] = (bit_len >> 32) & 0xFF;
    padded[padded_len - 4] = (bit_len >> 24) & 0xFF;
    padded[padded_len - 3] = (bit_len >> 16) & 0xFF;
    padded[padded_len - 2] = (bit_len >> 8) & 0xFF;
    padded[padded_len - 1] = bit_len & 0xFF;

    // Process blocks
    for (size_t block = 0; block < padded_len; block += 64) {
        uint32_t w[64];
        for (int i = 0; i < 16; i++) {
            w[i] = ((uint32_t)padded[block + i*4] << 24) |
                   ((uint32_t)padded[block + i*4 + 1] << 16) |
                   ((uint32_t)padded[block + i*4 + 2] << 8) |
                   ((uint32_t)padded[block + i*4 + 3]);
        }

        for (int i = 16; i < 64; i++) {
            uint32_t s0 = ((w[i-15] >> 7) | (w[i-15] << 25)) ^ ((w[i-15] >> 18) | (w[i-15] << 14)) ^ (w[i-15] >> 3);
            uint32_t s1 = ((w[i-2] >> 17) | (w[i-2] << 15)) ^ ((w[i-2] >> 19) | (w[i-2] << 13)) ^ (w[i-2] >> 10);
            w[i] = w[i-16] + s0 + w[i-7] + s1;
        }

        uint32_t a = h[0], b = h[1], c = h[2], d = h[3];
        uint32_t e = h[4], f = h[5], g = h[6], hh = h[7];

        for (int i = 0; i < 64; i++) {
            uint32_t S1 = ((e >> 6) | (e << 26)) ^ ((e >> 11) | (e << 21)) ^ ((e >> 25) | (e << 7));
            uint32_t ch = (e & f) ^ ((~e) & g);
            uint32_t temp1 = hh + S1 + ch + k[i] + w[i];
            uint32_t S0 = ((a >> 2) | (a << 30)) ^ ((a >> 13) | (a << 19)) ^ ((a >> 22) | (a << 10));
            uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t temp2 = S0 + maj;

            hh = g; g = f; f = e; e = d + temp1;
            d = c; c = b; b = a; a = temp1 + temp2;
        }

        h[0] += a; h[1] += b; h[2] += c; h[3] += d;
        h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
    }

    for (int i = 0; i < 8; i++) {
        hash[i*4] = (h[i] >> 24) & 0xFF;
        hash[i*4 + 1] = (h[i] >> 16) & 0xFF;
        hash[i*4 + 2] = (h[i] >> 8) & 0xFF;
        hash[i*4 + 3] = h[i] & 0xFF;
    }
}

void privkey_to_wif(const uint64_t* key, char* wif, bool compressed) {
    uint8_t data[38];
    data[0] = 0x80;  // Mainnet prefix

    // Copy key bytes (big-endian)
    for (int i = 0; i < 32; i++) {
        data[1 + i] = ((uint8_t*)key)[31 - i];
    }

    int dataLen = 33;
    if (compressed) {
        data[33] = 0x01;  // Compression flag
        dataLen = 34;
    }

    // Compute checksum: first 4 bytes of double SHA256
    uint8_t sha1[32], sha2[32];
    sha256_host(data, dataLen, sha1);
    sha256_host(sha1, 32, sha2);

    data[dataLen] = sha2[0];
    data[dataLen+1] = sha2[1];
    data[dataLen+2] = sha2[2];
    data[dataLen+3] = sha2[3];
    dataLen += 4;

    // Base58 encode
    int zeros = 0;
    while (zeros < dataLen && data[zeros] == 0) zeros++;

    uint8_t temp[64];
    int tempLen = 0;

    for (int i = 0; i < dataLen; i++) {
        int carry = data[i];
        for (int j = 0; j < tempLen; j++) {
            carry += 256 * temp[j];
            temp[j] = carry % 58;
            carry /= 58;
        }
        while (carry > 0) {
            temp[tempLen++] = carry % 58;
            carry /= 58;
        }
    }

    int idx = 0;
    for (int i = 0; i < zeros; i++) wif[idx++] = '1';
    for (int i = tempLen - 1; i >= 0; i--) wif[idx++] = b58_alphabet[temp[i]];
    wif[idx] = '\0';
}

// Host-side hash160 to address with CORRECT double-SHA256 checksum
void hash160_to_address_host(const uint8_t* hash160, char* addr) {
    uint8_t data[25];
    data[0] = 0x00;  // Mainnet P2PKH version byte
    memcpy(data + 1, hash160, 20);

    // Compute checksum: first 4 bytes of double SHA256
    uint8_t sha1[32], sha2[32];
    sha256_host(data, 21, sha1);
    sha256_host(sha1, 32, sha2);

    data[21] = sha2[0];
    data[22] = sha2[1];
    data[23] = sha2[2];
    data[24] = sha2[3];

    int zeros = 0;
    while (zeros < 25 && data[zeros] == 0) zeros++;

    uint8_t temp[35];
    int tempLen = 0;

    for (int i = 0; i < 25; i++) {
        int carry = data[i];
        for (int j = 0; j < tempLen; j++) {
            carry += 256 * temp[j];
            temp[j] = carry % 58;
            carry /= 58;
        }
        while (carry > 0) {
            temp[tempLen++] = carry % 58;
            carry /= 58;
        }
    }

    int idx = 0;
    for (int i = 0; i < zeros; i++) addr[idx++] = '1';
    for (int i = tempLen - 1; i >= 0; i--) addr[idx++] = b58_alphabet[temp[i]];
    addr[idx] = '\0';
}

// =====================================================================================
// HOST-SIDE POST-MATCH VERIFICATION
// =====================================================================================
//
// Every match reported by the GPU is re-derived from scratch on the host:
// reconstruct the private key -> scalar_mult_G -> compressed pubkey ->
// SHA-256 -> RIPEMD-160 -> compare hash160 to what the GPU reported.
//
// A verified match round-trips perfectly. An unverified match means either
// (a) a bug in reconstruct_privkey's offset math (historically where iter-
// on-resume went wrong), (b) GPU memory corruption, or (c) a kernel bug in
// the hash pipeline. In any of those cases we still log the result, but
// with a loud "UNVERIFIED" marker so downstream import attempts don't fail
// silently hours later.
//
// Only the compressed-path matches (parity ∈ {0, 1}) are verified here.
// Uncompressed matches (parity ∈ {2, 3}) are a legacy prefix-mode feature
// and skip verification — they're not emitted in -direct mode at all.

static void privkey_to_hash160_compressed(const uint64_t* privkey, bool oddY,
                                          uint8_t* out20) {
    uint64_t px[4], py[4];
    scalar_mult_G(px, py, privkey);

    // Compressed SEC: 0x02 for even Y, 0x03 for odd Y, then 32 bytes of X big-endian.
    uint8_t pubkey[33];
    pubkey[0] = oddY ? 0x03 : 0x02;
    const uint8_t* pxBytes = (const uint8_t*)px;
    for (int i = 0; i < 32; i++) pubkey[1 + i] = pxBytes[31 - i];

    uint8_t sha[32];
    sha256_host(pubkey, 33, sha);
    ripemd160(sha, 32, out20);
}

// Returns true if the reconstructed key round-trips to the reported hash160.
// parity: 0 = even-Y compressed, 1 = odd-Y compressed, 2/3 = uncompressed
// (legacy prefix mode) — for uncompressed, skip verification and return true.
static bool verify_match(const uint64_t* privkey, const uint8_t* reported_h160,
                         uint8_t parity) {
    if (parity != 0 && parity != 1) return true;  // legacy uncompressed: skip
    uint8_t derived[20];
    privkey_to_hash160_compressed(privkey, parity == 1, derived);
    return memcmp(derived, reported_h160, 20) == 0;
}

// Load patterns
// Base58 decode a Bitcoin P2PKH address into its 20-byte hash160.
// Returns true on success, false if the address is malformed or checksum fails.
// The implementation mirrors the host-side encoder in reverse.
static bool address_to_hash160_host(const char* addr, uint8_t* out20) {
    static const int8_t b58map[128] = {
        // Map '1'..'z' to Base58 index, -1 for invalid.
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1, 0, 1, 2, 3, 4, 5, 6, 7, 8,-1,-1,-1,-1,-1,-1,
        -1, 9,10,11,12,13,14,15,16,-1,17,18,19,20,21,-1,
        22,23,24,25,26,27,28,29,30,31,32,-1,-1,-1,-1,-1,
        -1,33,34,35,36,37,38,39,40,41,42,43,-1,44,45,46,
        47,48,49,50,51,52,53,54,55,56,57,-1,-1,-1,-1,-1
    };

    int addrLen = (int)strlen(addr);
    if (addrLen < 26 || addrLen > 35) return false;

    int zeros = 0;
    while (zeros < addrLen && addr[zeros] == '1') zeros++;

    uint8_t decoded[32] = {0};
    int decLen = 0;

    for (int i = zeros; i < addrLen; i++) {
        unsigned char c = (unsigned char)addr[i];
        if (c >= 128) return false;
        int8_t v = b58map[c];
        if (v < 0) return false;
        int carry = v;
        for (int j = 0; j < decLen; j++) {
            carry += (int)decoded[j] * 58;
            decoded[j] = carry & 0xFF;
            carry >>= 8;
        }
        while (carry) {
            if (decLen >= 32) return false;
            decoded[decLen++] = carry & 0xFF;
            carry >>= 8;
        }
    }

    // Reverse + prepend leading-zero bytes for each leading '1'.
    uint8_t result[32] = {0};
    int rlen = zeros + decLen;
    if (rlen != 25) return false;  // P2PKH decodes to exactly 25 bytes
    for (int i = 0; i < decLen; i++) result[zeros + (decLen - 1 - i)] = decoded[i];

    // Verify version byte = 0x00 (mainnet P2PKH).
    if (result[0] != 0x00) return false;

    // Verify checksum.
    uint8_t sha1[32], sha2[32];
    sha256_host(result, 21, sha1);
    sha256_host(sha1, 32, sha2);
    if (memcmp(result + 21, sha2, 4) != 0) return false;

    memcpy(out20, result + 1, 20);
    return true;
}

int load_patterns(const char* filename, char patterns[][36], int* lens, int max_patterns) {
    FILE* f = fopen(filename, "r");
    if (!f) {
        printf("Error: Cannot open patterns file: %s\n", filename);
        return 0;
    }

    int count = 0;
    char line[256];

    while (fgets(line, sizeof(line), f) && count < max_patterns) {
        int len = strlen(line);
        while (len > 0 && (line[len-1] == '\n' || line[len-1] == '\r')) {
            line[--len] = '\0';
        }

        if (len == 0 || line[0] == '#') continue;
        if (len > 35) {
            printf("Warning: pattern exceeds 35 chars, rejected: %s\n", line);
            continue;
        }
        if (line[0] != '1') {
            printf("Warning: Skipping pattern (must start with '1'): %s\n", line);
            continue;
        }

        bool valid = true;
        for (int i = 0; i < len && valid; i++) {
            if (strchr("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz", line[i]) == NULL) {
                printf("Warning: Invalid Base58 char in: %s\n", line);
                valid = false;
            }
        }
        if (!valid) continue;

        strncpy(patterns[count], line, 35);
        patterns[count][35] = '\0';
        lens[count] = len;

        printf("Pattern %d: %s (len=%d)\n", count, patterns[count], lens[count]);
        count++;
    }

    fclose(f);
    return count;
}

void print_usage(const char* prog) {
    printf("SearchK4 - GPU key search (vanity prefix OR hash160-direct puzzle mode)\n\n");
    printf("Usage: %s -patterns <file> (-start <dec> | -startx <hex> | -state <file>) [options]\n\n", prog);
    printf("Required (one of):\n");
    printf("  -start <value>     Starting private key (decimal)\n");
    printf("  -startx <value>    Starting private key (hex, 0x prefix optional)\n");
    printf("  -state <file>      Resume from state file\n\n");
    printf("Required:\n");
    printf("  -patterns <file>   File with address prefixes OR full addresses (one per line)\n\n");
    printf("Mode:\n");
    printf("  -direct            Hash160-direct match mode. Requires full addresses in\n");
    printf("                     -patterns (not prefixes). Skips Base58 + uncompressed check.\n");
    printf("                     Recommended for puzzle solving.\n\n");
    printf("Range clamping (strongly recommended for puzzle work):\n");
    printf("  -endx <hex>        Last private key to search (inclusive). Kernel terminates\n");
    printf("                     cleanly when range is exhausted.\n");
    printf("  -bits <N>          Shortcut: search range [2^(N-1), 2^N - 1]. E.g. -bits 71\n");
    printf("                     for Puzzle #71. Sets both -startx and -endx. Overridden\n");
    printf("                     by explicit -startx / -endx.\n\n");
    printf("Other:\n");
    printf("  -gpu <id>          GPU device ID (default: 0)\n");
    printf("  -threads <N>       CUDA thread count (default: 1024; try 16384 in -direct mode)\n");
    printf("  -o <file>          Output file (default: found_k4.txt)\n");
    printf("  -verbose           Print per-iteration progress logs (noisy)\n");
    printf("  -h, --help         Show this help\n\n");
    printf("Examples:\n");
    printf("  # Smoke test: Puzzle #1 (key = 1, address 1BgGZ9tcN4rm9KBzDn7KprQz87SZ26SAMH)\n");
    printf("  %s -patterns puzzle1.txt -direct -bits 1\n\n", prog);
    printf("  # Puzzle #71, direct mode, GPU 0:\n");
    printf("  %s -patterns patterns.txt -direct -bits 71 -threads 16384 -gpu 0\n\n", prog);
    printf("  # Resume GPU 0 after interruption (reads -threads from state file):\n");
    printf("  %s -patterns patterns.txt -direct -state gpu0.state -bits 71\n\n", prog);
}

int main(int argc, char** argv) {
    char* patternsFile = NULL;
    char* stateFile = NULL;
    char* outputFile = (char*)"found_k4.txt";
    char* startDecimal = NULL;
    char* startHex = NULL;
    char* endHex = NULL;
    int gpuId = 0;
    int threadCount = 0;  // 0 = use default
    int directMode = 0;
    int bits = 0;
    int verbose = 0;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-patterns") && i+1 < argc) patternsFile = argv[++i];
        else if (!strcmp(argv[i], "-gpu") && i+1 < argc) gpuId = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-state") && i+1 < argc) stateFile = argv[++i];
        else if (!strcmp(argv[i], "-o") && i+1 < argc) outputFile = argv[++i];
        else if (!strcmp(argv[i], "-start") && i+1 < argc) startDecimal = argv[++i];
        else if (!strcmp(argv[i], "-startx") && i+1 < argc) startHex = argv[++i];
        else if (!strcmp(argv[i], "-endx") && i+1 < argc) endHex = argv[++i];
        else if (!strcmp(argv[i], "-bits") && i+1 < argc) bits = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-threads") && i+1 < argc) threadCount = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-direct")) directMode = 1;
        else if (!strcmp(argv[i], "-verbose")) verbose = 1;
        else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
            print_usage(argv[0]);
            return 0;
        }
    }

    if (!patternsFile) {
        print_usage(argv[0]);
        return 1;
    }

    // ---------------------------------------------------------------
    // Input validation. Each check errors out early with a clear message
    // rather than letting a bad flag cascade into a silent coverage bug.
    // ---------------------------------------------------------------

    if (gpuId < 0) {
        printf("Error: -gpu must be >= 0 (got %d)\n", gpuId);
        return 1;
    }

    // threads must be a positive multiple of NB_THREAD_PER_GROUP.
    // The kernel launches <<<nbThread/NB_THREAD_PER_GROUP, NB_THREAD_PER_GROUP>>>
    // and per-thread key storage assumes the block-strided layout. A value that
    // isn't a clean multiple produces a truncated launch and silent miscoverage.
    if (threadCount != 0) {
        if (threadCount < NB_THREAD_PER_GROUP ||
            (threadCount % NB_THREAD_PER_GROUP) != 0) {
            printf("Error: -threads must be a positive multiple of %d (got %d)\n",
                   NB_THREAD_PER_GROUP, threadCount);
            return 1;
        }
    }

    if (bits < 0 || bits > 256) {
        printf("Error: -bits must be in [1, 256] (got %d)\n", bits);
        return 1;
    }

    // startDecimal / startHex / endHex strict parse happens below, after -bits
    // has had a chance to populate them. We validate user-supplied values only.
    auto check_hex = [](const char* s, const char* flag) -> bool {
        uint64_t tmp[4];
        if (!hex_to_256bit_strict(s, tmp)) {
            printf("Error: %s is not a valid 1..64 hex-digit value: \"%s\"\n", flag, s);
            return false;
        }
        return true;
    };
    auto check_dec = [](const char* s, const char* flag) -> bool {
        uint64_t tmp[4];
        if (!decimal_to_256bit_strict(s, tmp)) {
            printf("Error: %s is not a valid decimal (or overflows 2^256): \"%s\"\n", flag, s);
            return false;
        }
        return true;
    };

    if (startHex    && !check_hex(startHex,    "-startx")) return 1;
    if (endHex      && !check_hex(endHex,      "-endx"))   return 1;
    if (startDecimal && !check_dec(startDecimal, "-start")) return 1;

    // -bits N shortcut: range [2^(N-1), 2^N - 1]. Does not override explicit -startx/-endx.
    char bitsStart[80], bitsEnd[80];
    if (bits > 0 && bits <= 256) {
        // 2^(bits-1) as hex — little-endian 256-bit built as string.
        uint64_t bsk[4] = {0};
        uint64_t bek[4] = {0};
        int lowBit = bits - 1;
        bsk[lowBit / 64] = 1ULL << (lowBit % 64);
        // End = 2^bits - 1. Fill all bits below 'bits' with 1.
        for (int b = 0; b < bits; b++) {
            bek[b / 64] |= 1ULL << (b % 64);
        }
        snprintf(bitsStart, sizeof(bitsStart), "%016lx%016lx%016lx%016lx",
                 bsk[3], bsk[2], bsk[1], bsk[0]);
        snprintf(bitsEnd, sizeof(bitsEnd), "%016lx%016lx%016lx%016lx",
                 bek[3], bek[2], bek[1], bek[0]);
        if (!startHex && !startDecimal) startHex = bitsStart;
        if (!endHex) endHex = bitsEnd;
        printf("-bits %d: range [0x%s .. 0x%s]\n", bits, bitsStart, bitsEnd);
    }

    // Load patterns
    char h_patterns[K4_MAX_PATTERNS][36];
    int h_lens[K4_MAX_PATTERNS];
    int numPatterns = load_patterns(patternsFile, h_patterns, h_lens, K4_MAX_PATTERNS);
    if (numPatterns == 0) {
        printf("Error: No valid patterns loaded\n");
        return 1;
    }
    printf("Loaded %d patterns\n\n", numPatterns);

    char defaultState[256];
    if (!stateFile) {
        snprintf(defaultState, 256, "gpu%d.state", gpuId);
        stateFile = defaultState;
    }

    signal(SIGINT, sighandler);
    signal(SIGTERM, sighandler);
    cudaSetDevice(gpuId);

    // Increase stack size limit for larger kernels with uncompressed address support
    cudaDeviceSetLimit(cudaLimitStackSize, 36 * 1024);  // 36KB per thread (kernel needs ~33KB)

    cudaDeviceProp prop;
    cudaGetDeviceProperties(&prop, gpuId);
    printf("GPU %d: %s (SM %d.%d, %d MPs)\n", gpuId, prop.name, prop.major, prop.minor, prop.multiProcessorCount);

    // Copy patterns to GPU constant memory
    cudaError_t err;
    err = cudaMemcpyToSymbol(d_patterns, h_patterns, sizeof(h_patterns));
    if (err != cudaSuccess) {
        printf("CUDA ERROR copying patterns: %s\n", cudaGetErrorString(err));
        return 1;
    }
    err = cudaMemcpyToSymbol(d_pattern_lens, h_lens, sizeof(h_lens));
    if (err != cudaSuccess) {
        printf("CUDA ERROR copying pattern lengths: %s\n", cudaGetErrorString(err));
        return 1;
    }
    err = cudaMemcpyToSymbol(d_num_patterns, &numPatterns, sizeof(int));
    if (err != cudaSuccess) {
        printf("CUDA ERROR copying num_patterns: %s\n", cudaGetErrorString(err));
        return 1;
    }
    printf("Successfully copied %d patterns to GPU constant memory\n", numPatterns);

    // If -direct, decode each pattern as a full address into a hash160 target.
    // Any pattern that is not a valid 25-byte P2PKH address is rejected.
    int numTargets = 0;
    if (directMode) {
        uint32_t h_targets[K4_MAX_PATTERNS][5];
        memset(h_targets, 0, sizeof(h_targets));
        for (int i = 0; i < numPatterns; i++) {
            uint8_t hash160[20];
            if (!address_to_hash160_host(h_patterns[i], hash160)) {
                printf("Warning: -direct mode skipping non-address pattern: %s\n", h_patterns[i]);
                continue;
            }
            // Pack 20 bytes into 5 uint32 little-endian (matches _GetHash160CompSym output).
            for (int w = 0; w < 5; w++) {
                h_targets[numTargets][w] =
                    ((uint32_t)hash160[w*4 + 0])       |
                    ((uint32_t)hash160[w*4 + 1]) << 8  |
                    ((uint32_t)hash160[w*4 + 2]) << 16 |
                    ((uint32_t)hash160[w*4 + 3]) << 24;
            }
            numTargets++;
        }
        if (numTargets == 0) {
            printf("Error: -direct mode requires at least one full address in -patterns\n");
            return 1;
        }
        err = cudaMemcpyToSymbol(d_target_h160, h_targets, sizeof(h_targets));
        if (err != cudaSuccess) {
            printf("CUDA ERROR copying target hash160s: %s\n", cudaGetErrorString(err));
            return 1;
        }
        err = cudaMemcpyToSymbol(d_num_targets, &numTargets, sizeof(int));
        if (err != cudaSuccess) {
            printf("CUDA ERROR copying num_targets: %s\n", cudaGetErrorString(err));
            return 1;
        }
        printf("Direct mode: %d hash160 targets uploaded\n", numTargets);
    } else {
        int zero = 0;
        cudaMemcpyToSymbol(d_num_targets, &zero, sizeof(int));
    }
    err = cudaMemcpyToSymbol(d_direct_mode, &directMode, sizeof(int));
    if (err != cudaSuccess) {
        printf("CUDA ERROR copying direct_mode: %s\n", cudaGetErrorString(err));
        return 1;
    }

    // Range-end clamping.
    uint64_t endKey[4] = {0};
    int haveEndx = 0;
    if (endHex) {
        hex_to_256bit(endHex, endKey);
        haveEndx = 1;
        char ehex[65];
        format_256bit_hex(endKey, ehex);
        printf("Range end: 0x%s (inclusive)\n", ehex);
    }
    cudaMemcpyToSymbol(d_endKey, endKey, 32);
    cudaMemcpyToSymbol(d_have_endx, &haveEndx, sizeof(int));

    // Default to 1024 threads in legacy mode (register pressure from uncompressed check);
    // in -direct mode the uncompressed branch is skipped, so 16384 is safe.
    int defaultThreads = directMode ? 16384 : 1024;
    int nbThread = (threadCount > 0) ? threadCount : defaultThreads;
    g_nbThread = nbThread;
    printf("Using %d threads (mode: %s)\n", nbThread, directMode ? "direct" : "prefix");
    uint64_t* d_keys;
    uint32_t* d_found;
    uint64_t* d_dx;     // Global memory for dx arrays (avoids stack overflow)
    uint64_t* d_subp;   // Global memory for subp arrays (avoids stack overflow)

    err = cudaMalloc(&d_keys, nbThread * 64);
    if (err != cudaSuccess) {
        printf("CUDA ERROR allocating d_keys: %s\n", cudaGetErrorString(err));
        return 1;
    }
    err = cudaMalloc(&d_found, (1 + MAX_FOUND * 8) * 4);
    if (err != cudaSuccess) {
        printf("CUDA ERROR allocating d_found: %s\n", cudaGetErrorString(err));
        return 1;
    }

    // Allocate global memory for dx and subp arrays to avoid stack overflow
    // Each thread needs (GRP_SIZE/2+1) * 4 uint64_t values = 513 * 4 * 8 = 16416 bytes
    size_t dxSize = (size_t)nbThread * (GRP_SIZE / 2 + 1) * 4 * sizeof(uint64_t);
    printf("Allocating dx buffer: %zu bytes (%.2f MB)\n", dxSize, dxSize / 1048576.0);
    err = cudaMalloc(&d_dx, dxSize);
    if (err != cudaSuccess) {
        printf("CUDA ERROR allocating d_dx: %s\n", cudaGetErrorString(err));
        return 1;
    }
    err = cudaMalloc(&d_subp, dxSize);
    if (err != cudaSuccess) {
        printf("CUDA ERROR allocating d_subp: %s\n", cudaGetErrorString(err));
        return 1;
    }
    printf("Allocated global memory for dx and subp arrays\n");

    uint64_t* h_keys = (uint64_t*)malloc(nbThread * 64);
    uint64_t resumedKeys = 0;

    // Initialize keys - SEQUENTIAL MODE ONLY (random mode disabled)
    if (startDecimal || startHex) {
        if (startHex) {
            init_keys_from_start(h_keys, nbThread, startHex, true);
        } else {
            init_keys_from_start(h_keys, nbThread, startDecimal, false);
        }
    } else {
        uint64_t loadedBase[4] = {0};
        int loadedThreads = 0;
        uint64_t resumedIter = 0;
        resumedKeys = load_state_seq(stateFile, h_keys, nbThread, loadedBase,
                                     &loadedThreads, &resumedIter);

        if (resumedKeys > 0 && (loadedBase[0] | loadedBase[1] | loadedBase[2] | loadedBase[3]) != 0) {
            if (loadedThreads > 0 && loadedThreads != nbThread) {
                printf("ERROR: state file was saved with %d threads, current run uses %d.\n",
                       loadedThreads, nbThread);
                printf("       Re-run with -threads %d, or start fresh.\n", loadedThreads);
                free(h_keys);
                return 1;
            }
            memcpy(g_baseKey, loadedBase, sizeof(g_baseKey));
            g_sequentialMode = true;
            g_nbThread = nbThread;
            // CRITICAL: re-upload sequential-advance delta, which is not part of the
            // state file. Without this, the kernel reverts to STEP_SIZE-only advance
            // and threads silently re-scan the same slices.
            upload_seq_delta(nbThread);

            char hexStr[65];
            format_256bit_hex(g_baseKey, hexStr);
            printf("Resumed SEQUENTIAL from %.2fB keys (iter=%lu)\n",
                   resumedKeys/1e9, resumedIter);
            printf("  Base key: 0x%s\n", hexStr);

            // Carry the resumed iter forward — used in the main-loop initialiser below.
            g_resumedIter = resumedIter;
        } else {
            printf("\nERROR: No starting key specified and no valid sequential state file found.\n");
            printf("Use -start, -startx, or -bits <N>. See --help.\n\n");
            free(h_keys);
            cudaFree(d_keys);
            cudaFree(d_found);
            cudaFree(d_dx);
            cudaFree(d_subp);
            return 1;
        }
    }

    printf("\nMode: SEQUENTIAL | %s | %d threads | %d patterns\n",
           directMode ? "hash160-direct" : "prefix-match",
           nbThread, directMode ? numTargets : numPatterns);
    printf("Output: %s\n\n", outputFile);

    // Final sanity check on the reconstructed search range. By now g_baseKey
    // has been populated by init_keys_from_start or load_state_seq; endKey is
    // set if -endx (or -bits) was given.
    {
        bool baseIsZero =
            (g_baseKey[0] | g_baseKey[1] | g_baseKey[2] | g_baseKey[3]) == 0;
        if (baseIsZero) {
            printf("Error: start key is 0 (invalid — secp256k1 requires 1 <= k < N)\n");
            return 1;
        }
        if (cmp256(g_baseKey, SECP_N) >= 0) {
            printf("Error: start key must be strictly less than the curve order N\n");
            return 1;
        }
        if (haveEndx) {
            if (cmp256(endKey, SECP_N) >= 0) {
                printf("Error: -endx must be strictly less than the curve order N\n");
                return 1;
            }
            if (cmp256(endKey, g_baseKey) < 0) {
                char s[65], e[65];
                format_256bit_hex(g_baseKey, s);
                format_256bit_hex(endKey, e);
                printf("Error: -endx (0x%s) is below start (0x%s) — empty range\n", e, s);
                return 1;
            }
        }
    }

    time_t start = time(NULL);
    uint64_t total = resumedKeys;
    uint64_t iter  = g_resumedIter;  // carried across resume — see load_state_seq
    uint64_t keysPerIter = (uint64_t)nbThread * STEP_SIZE;

    while (running) {
        cudaMemset(d_found, 0, 4);
        searchK4_kernel<<<nbThread/NB_THREAD_PER_GROUP, NB_THREAD_PER_GROUP>>>(
            d_dx, d_subp, 0, d_keys, MAX_FOUND, d_found);
        cudaDeviceSynchronize();

        cudaError_t kerr = cudaGetLastError();
        if (kerr != cudaSuccess) {
            printf("\nCUDA Error: %s\n", cudaGetErrorString(kerr));
            break;
        }

        // One copy for count + payload. Max payload ~2 MB, pinned, fast.
        cudaMemcpy(h_found, d_found, (1 + MAX_FOUND * 8) * 4, cudaMemcpyDeviceToHost);

        if (h_found[0] > 0) {
            uint32_t nFound = h_found[0];
            if (nFound > MAX_FOUND) nFound = MAX_FOUND;

            FILE* mf = fopen(outputFile, "a");
            time_t now = time(NULL);
            char* timestr = ctime(&now);
            timestr[strlen(timestr)-1] = '\0';

            printf("\n[!] Found %u match%s!\n", nFound, nFound == 1 ? "" : "es");

            for (uint32_t i = 0; i < nFound; i++) {
                uint32_t* entry = h_found + 1 + i*8;
                uint32_t tid = entry[0];
                int32_t incr = (int32_t)entry[1];
                int pattern_idx = (entry[2] >> 8) & 0xFF;
                uint8_t isOdd = entry[2] & 0xFF;
                uint32_t* hash = entry + 3;

                uint8_t hash160[20];
                for (int w = 0; w < 5; w++) {
                    uint32_t v = hash[w];
                    hash160[w*4 + 0] = (v >> 0) & 0xFF;
                    hash160[w*4 + 1] = (v >> 8) & 0xFF;
                    hash160[w*4 + 2] = (v >> 16) & 0xFF;
                    hash160[w*4 + 3] = (v >> 24) & 0xFF;
                }

                char addr[40];
                hash160_to_address_host(hash160, addr);

                const char* pattern = (pattern_idx >= 0 && pattern_idx < numPatterns) ?
                                       h_patterns[pattern_idx] : "?";

                uint64_t privkey[4];
                reconstruct_privkey(privkey, tid, incr, iter, isOdd);

                // Host-side post-match verification: re-derive hash160 from the
                // reconstructed privkey and compare. Catches iter/offset bugs and
                // GPU-side memory corruption before the key hits the output file.
                bool verified = verify_match(privkey, hash160, isOdd);

                char hexKey[65], wifKey[60];
                format_256bit_hex(privkey, hexKey);
                bool isCompressed = (isOdd == 0 || isOdd == 1);
                privkey_to_wif(privkey, wifKey, isCompressed);

                const char* addrType = isCompressed ? "compressed" : "uncompressed";
                if (!verified) {
                    fprintf(mf,
                        "[%s] UNVERIFIED Pattern='%s' Address=%s (%s) "
                        "-- RECONSTRUCTION MISMATCH, DO NOT IMPORT WITHOUT INVESTIGATION\n",
                        timestr, pattern, addr, addrType);
                } else {
                    fprintf(mf, "[%s] Pattern='%s' Address=%s (%s)\n",
                            timestr, pattern, addr, addrType);
                }
                fprintf(mf, "  PrivKey (HEX): 0x%s\n", hexKey);
                fprintf(mf, "  PrivKey (WIF): %s\n", wifKey);
                fprintf(mf, "  Hash160: ");
                for (int b = 0; b < 20; b++) fprintf(mf, "%02x", hash160[b]);
                fprintf(mf, "\n  tid=%u incr=%d parity=%d iter=%lu verified=%s\n\n",
                        tid, incr, isOdd, iter, verified ? "yes" : "NO");

                if (verified) {
                    printf("  %s -> Pattern: %s\n", addr, pattern);
                    printf("    PrivKey: 0x%s\n", hexKey);
                    printf("    WIF:     %s\n", wifKey);
                } else {
                    printf("  [!] UNVERIFIED match for %s (pattern %s) — see %s\n",
                           addr, pattern, outputFile);
                }
            }
            fclose(mf);
        }

        total += keysPerIter;
        iter++;

        // Range-end termination: check whether the last key we just covered has passed endKey.
        // "Last key this iter" ≈ g_baseKey + total - 1.
        if (haveEndx) {
            uint64_t covered[4] = {total, 0, 0, 0};
            uint64_t current[4];
            add256(current, g_baseKey, covered);
            if (cmp256(current, endKey) > 0) {
                printf("\n\n[+] Range end reached (covered past 0x");
                char ehex[65]; format_256bit_hex(endKey, ehex);
                printf("%s). Stopping.\n", ehex);
                running = false;
            }
        }

        if (iter % 500 == 0) {
            cudaMemcpy(h_keys, d_keys, nbThread * 64, cudaMemcpyDeviceToHost);
            save_state_seq(stateFile, h_keys, nbThread, total, iter, g_baseKey);
        }

        if (iter % 10 == 0 || verbose) {
            double t = difftime(time(NULL), start);
            if (t < 1) t = 1;
            double rate = (double)(total - resumedKeys) / t / 1e9;
            printf("\r[%5.0fs] Covered: %.3fB keys | %.2f GKey/s | iter=%lu     ",
                   t, total/1e9, rate, iter);
            fflush(stdout);
        }
    }

    printf("\n\nSaving state...\n");
    cudaMemcpy(h_keys, d_keys, nbThread * 64, cudaMemcpyDeviceToHost);
    save_state_seq(stateFile, h_keys, nbThread, total, iter, g_baseKey);
    printf("Total: %.2fB keys (iter=%lu)\n", total/1e9, iter);

    cudaFree(d_keys);
    cudaFree(d_found);
    cudaFree(d_dx);
    cudaFree(d_subp);
    cudaFreeHost(h_found);
    free(h_keys);

    return 0;
}
