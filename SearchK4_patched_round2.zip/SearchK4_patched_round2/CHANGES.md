# SearchK4 Patch Log

All changes applied to the v1.4 baseline in a single patch session. The scope is:

- Two correctness fixes (one was a silent bug, one was missing entirely).
- One algorithmic change (direct hash160 match) that gives a material speedup and simplifies the design.
- Build-system and UX cleanup.
- A restraint layer around which targets and ranges the tool will accept.

None of the math was touched. The secp256k1 primitives, Jacobian EC formulas, Montgomery batch inversion, `_GetHash160CompSym`, and the strided memory layout are all unchanged. What changed is how the tool is configured, how it enters and exits the search, and what happens after a candidate hash is produced.

---

## 1. Correctness: state-resume no longer silently re-scans

### Problem

The previous resume path loaded the base key and per-thread keys from the state file, set `g_sequentialMode = true`, and proceeded. What it did not do was re-upload the `d_seqDeltaX`, `d_seqDeltaY`, and `d_useSeqDelta` device-constant symbols. Those were only set inside `init_keys_from_start()`, which runs on fresh starts and is skipped on resume.

The effect: after resume, `d_useSeqDelta` remained at its zero-initialized value, the `if (d_useSeqDelta)` branch in `ComputeKeysK4` was skipped, and every iteration advanced each thread by just `STEP_SIZE × G` instead of the intended `nbThread × STEP_SIZE × G`. Threads overlapped. The scan re-covered the same 1024-key slices forever. No warning, no error — the rate counter still showed ~6.7 GKey/s because the same number of kernel operations ran; they just weren't covering new keys.

### Fix

Extracted the delta computation into a standalone function `upload_seq_delta(int nbThread)` that computes `(nbThread − 1) × STEP_SIZE × G` via `scalar_mult_G()` and uploads the three constants. Called from both `init_keys_from_start()` and the resume branch in `main()`.

### Why the bug was hard to spot from the outside

Correct sequential coverage and incorrect overlapping coverage both run at the same keys-per-second rate from the GPU's perspective. The only way to detect it without running for long enough to solve a puzzle is to inspect `d_keys` after iteration 1 versus iteration N: with the bug, many thread positions repeat; without it, they're all distinct. The existing rate-reporting loop in `main()` shows the same headline number in both cases.

---

## 2. Correctness: state file now stores `nbThread`

### Problem

The v1 state format was `[8B total] [32B base key] [keys data]`. The number of threads (`nbThread`) was not stored. If you saved state with `-threads 16384` and resumed with `-threads 1024`, the per-thread-key layout would be wrong (different blocks/stride), the `upload_seq_delta` call would compute a delta for the wrong `nbThread`, and everything after that was silently wrong.

### Fix

New v2 format: `[8B magic "SK4STv02"] [8B total] [32B base key] [4B nbThread] [4B pad] [keys data]`. On load, if `nbThread` is stored and doesn't match the current flag, `main()` errors out with the required value. If the magic is absent (v1 file), the loader falls back to the old format but prints a note — you have to pass the right `-threads` yourself.

### Implementation

`save_state_seq` writes the magic first, then the counter, base key, `nbThread` (as `uint32`), 4 bytes of padding, and the keys. `load_state_seq` returns the loaded `nbThread` through an out-param (`int*`) so the caller can compare before committing to using the file. Backward-compat branch in the same function handles v1 files.

---

## 3. Algorithmic: hash160-direct match mode

### Problem with the previous design

The previous kernel did this for every candidate key:

1. `_GetHash160CompSym(px, h1, h2)` — produces hash160s for both compressed Y parities.
2. `_GetAddress(P2PKH, h1, addr)` — converts hash160 + version byte + double-SHA256 checksum into a 25-byte blob, then base58-encodes it via repeated modular division (~25-byte long division in the kernel).
3. String prefix-match against N patterns.
4. Repeat steps 2–3 for `h2`.
5. Repeat steps 1–4 for `_GetHash160(px, py, ...)` (uncompressed) and `_GetHash160(px, -y, ...)` (uncompressed negated).

The Base58 long-division in step 2 is the single most expensive thing in the hot path after the EC arithmetic itself — probably several hundred cycles per candidate. And for puzzle work it's pure waste: the target addresses are fixed, known at launch time, and the only question the kernel needs to answer is "does this hash160 equal one of the targets?"

### New design

`-direct` flag. Host decodes each address in `patterns.txt` into its 20-byte hash160 and uploads the targets to `__constant__ uint32_t d_target_h160[K4_MAX_PATTERNS][5]`. The kernel runs `_GetHash160CompSym` as before, then does a direct 5-word compare against the target table. No Base58, no string match, no `_GetAddress` call at all in the hot path. `_GetAddress` is still used on the host after a match for display.

Also removed from the hot path in direct mode: the uncompressed-address checks. All Bitcoin Puzzle addresses are derived from compressed pubkeys (standard modern derivation). The two extra `_GetHash160(px, py, …)` calls and the `ModNeg256` in the previous design were chasing a class of match that doesn't exist for this target set.

### Register pressure and thread count

The previous design's four hash paths all stayed live simultaneously in the `CheckHashCompSymK4` function, which is why the `UNCOMPRESSED_ADDRESS_FIX.md` note recommended `-threads 1024` to avoid hangs at 16384. With direct mode doing two hashes instead of four and no Base58 kernel, the live register set shrinks dramatically. The default `nbThread` in direct mode is now 16384; in legacy prefix mode it's still 1024.

### Expected speedup

Two sources:

- **Hash work halved** (2 compressed hashes instead of 2 compressed + 2 uncompressed): ~40% of the per-candidate hash cost goes away.
- **Base58 eliminated**: harder to estimate without profiling, but Base58 long-division is nontrivial — my rough guess is 15–25% of the previous per-candidate time.

Combined, ~30–40% throughput improvement in direct mode is plausible. Actual number depends on whether the kernel is memory-bound or compute-bound on your specific GPU; on a 5090 the register pressure relief from smaller live sets probably unlocks more speedup than the raw op-count reduction alone.

### Why keep legacy prefix mode

Some users have vanity-address workflows (generate an address that starts with chosen characters, keep the key). Removing that capability wouldn't serve them. `-direct` is additive — off by default, explicit opt-in.

---

## 4. Range clamping

### Problem

Previously, `-startx` set a start with no corresponding end. For Puzzle #71 the key is in `[2^70, 2^71 − 1]`, but once the scan passed `2^71 − 1` it walked into `[2^71, …]` — which is Puzzle #72's range — with no signal to the user. At the achievable rate, nobody would exhaust a 2^70 range in a human lifetime, so practical exposure was low, but the tool had no concept of "done."

### Fix

Two new CLI options:

- `-endx <hex>` sets an inclusive end key. Uploaded to `d_endKey` as a device constant. After each kernel iteration, the host checks whether `g_baseKey + total` has passed `d_endKey`; if so, it prints a termination message and exits the loop cleanly (writes state, closes files).
- `-bits N` is a shortcut that sets the range to `[2^(N−1), 2^N − 1]` in one flag — use `-bits 71` to search Puzzle #71's range. Computes both `-startx` and `-endx`. Does not override either if explicitly set.

The termination check is done on the host between kernel launches rather than inside the kernel, which avoids any per-candidate branch but means the tool may scan slightly past `-endx` within a single iteration (up to `nbThread × STEP_SIZE` keys ≈ 16M in default config). For puzzle work where the range is much larger than one iteration this rounding is immaterial.

### Why not an in-kernel hard stop

A per-thread "is my key past the range?" check would add a branch to every candidate and cost a measurable fraction of throughput for a safety check that only matters in the last iteration. The current approach — host-side check between iterations — gives clean termination with zero hot-path overhead. If sub-million-key range precision were needed, the cheapest way to get it would be to shrink the iteration size (`nbThread × STEP_SIZE`) near the end, but that's not worth implementing for current targets.

---

## 5. Build system

### Fixes

- `CCAP` now defaults to `120` (Blackwell / RTX 5090) instead of `89` (Ada / RTX 4090). The auto-detection via `nvidia-smi` still works, so `make` on any supported card does the right thing; the default only matters when `nvidia-smi` isn't available.
- `-maxrregcount=64` bumped to `96`. At 64 registers/thread the compiler was spilling more than necessary. Ada and Blackwell have 64K registers per SM; at 96 regs × 64 threads/block = 6144 regs/block, occupancy is limited by other factors, not registers. Verify with `--ptxas-options=-v` output after build.
- New `smoke` target: compiles if needed, creates a one-address patterns file with Puzzle #1's target, runs with `-bits 1`, expects an immediate match. Good first thing to run after a build to prove the full pipeline works.
- `clean` now also removes `found_k4.txt` alongside the binary and state files.

### README

Rewritten end-to-end. Documents direct vs prefix mode, the CLI flags, the multi-GPU pattern with proper range splitting, resume semantics, and the architectural overview. Old README's `-arch=sm_89` reference is gone.

---

## 6. Cleanup

- Removed dead debug telemetry: `g_debugCounter`, `g_debugPx`, `g_debugHash`, the iter==0 dump of thread 0's starting point to stderr. Was useful during bring-up, pure noise now.
- Removed per-iteration `printf` of "Clearing d_found...", "Launching kernel...", "Waiting for kernel...", "Kernel complete" — that was ~100 lines/second of noise competing with the `\r` rate line. `-verbose` still exists if you want per-iteration progress logs.
- Collapsed the two-stage found-buffer copy (`cudaMemcpy 4 bytes` then `cudaMemcpy full`) into one copy of the full buffer. The full buffer is ~2 MB pinned, one copy is faster and less code.
- Dead affine `point_add` / `point_double` functions are still present but unused; left in place to avoid gratuitous churn. They're documented in the review as removable.
- `secure_random` still present, still unused, still doesn't check `fread` return — flagged in the review, not fixed here.

---

## 7. Restraints

This build is deliberately scoped. The restraints are in the code, not just in the docs:

### `patterns.txt` ships with exactly four addresses

Puzzles #71, #72, #73, #74. All four:
- Have public key ranges published by the puzzle creator.
- Are designated solver-reward addresses with funds specifically earmarked for whoever solves them.
- Are brute-force feasible (painfully) on consumer GPUs.
- Are in the `[2^70, 2^74 − 1]` band where sequential scan is the appropriate algorithm.

No dormant third-party wallets. No prefixes that could collide with unrelated live addresses.

### Direct mode rejects prefixes

`-direct` calls `address_to_hash160_host` on each line of the patterns file, which Base58-decodes the string, verifies the 4-byte double-SHA256 checksum, and verifies the version byte is 0x00 (mainnet P2PKH). Any line that doesn't decode as a valid full mainnet P2PKH address is rejected with a warning and skipped. A file that contains only prefixes will produce zero targets and the program exits with an error before any scan starts.

This means in direct mode the kernel fires only on exact matches against validated addresses. A 9-character prefix match that would have triggered in legacy mode simply cannot happen.

### Range end is explicit

`-bits N` is the documented way to configure the range. `--help` and the README both recommend it. Without `-endx` or `-bits`, the scan runs indefinitely; that's a documented behavior, not a silent wander.

### Smoke test uses Puzzle #1, not an arbitrary address

`make smoke` targets Puzzle #1 specifically — key = 1, address = `1BgGZ9tcN4rm9KBzDn7KprQz87SZ26SAMH`. This is the smallest published test vector and should match within a fraction of a second. It verifies: key derivation, Jacobian scalar multiply, strided memory layout, hash160 computation, direct-match comparison, WIF reconstruction, output formatting. If smoke passes, the pipeline is correct end-to-end and any failure at higher bit counts is a range/resource issue, not a math bug.

---

## 8. What was not done

- No kangaroo implementation for pubkey-exposed puzzles (#130, #135, …, #160). Different algorithm, different tool. `JeanLucPons/Kangaroo` is the reference.
- No compile verification. `nvcc` wasn't available in the environment where these patches were written. Syntactic checks were limited to brace/paren balance and symbol-reference tracing. You'll need to run `make` and resolve anything the compiler catches — most likely candidate for problems is the host-side `address_to_hash160_host` Base58-decode function, which was written from scratch here.
- No performance benchmark. The 30–40% speedup estimate for direct mode is reasoned from op-counts, not measured. Real numbers need a run.
- No multi-GPU orchestrator. You still launch one process per GPU manually, splitting the range via `-startx`/`-endx`. The README shows the pattern.
- The affine `point_add` / `point_double` dead code is still in place. The `mod_mul` triple-reduction (which reduces more than necessary; one of the branches is unreachable) is unchanged. Both are documented in the review as safe to leave.

---

## 9. File changes

| File | Change |
|---|---|
| `SearchK4_fast.cu` | All code changes above. Net +~150 lines. |
| `patterns.txt` | Replaced. Four puzzle addresses, commented ranges, time-to-solve estimates. |
| `Makefile` | Default arch `sm_120`, `-maxrregcount 96`, new `smoke` target, `clean` also removes `found_k4.txt`. |
| `README.md` | Rewritten. |
| `CHANGES.md` | This file (new). |

Unmodified:

- `GPUMath.h`, `GPUHash.h`, `GPUGroup.h`, `CPUGroup.h` — VanitySearch primitives. No changes needed.
- `SearchK4.cu` — original version, kept for reference.
- `DEBUGGING_HISTORY.md`, `UNCOMPRESSED_ADDRESS_FIX.md` — historical notes.
- All `test_*.cu` — scratch files from earlier debugging sessions.
